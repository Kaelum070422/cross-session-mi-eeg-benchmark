# BCICIV2a cross-session revision supplement

This package accompanies Xinpeng Zheng's revised paper, *Cross-Session Evaluation of Classical and Compact Decoders for Four-Class Motor-Imagery EEG*. It contains computational evidence, not a new clinical or laboratory data collection. There is currently no public repository URL or DOI assigned to this release.

## Start here

Keep the directory structure intact. Run commands from the folder containing this README. Python 3.12 was used; exact scientific package versions are pinned in `reproducibility/requirements.txt` and recorded in the run metadata.

```powershell
python -m pip install -r reproducibility/requirements.txt --extra-index-url https://download.pytorch.org/whl/cpu
```

Package availability and hardware can affect bitwise reproduction. Stored CSV outputs and SHA-256 manifests allow checks without retraining the neural network.

## Audit existing results without downloading EEG

```powershell
python reproducibility/validate_final_results.py --results-dir reproducibility/results_final_ensemble --output original_validation_rerun.json
python revision_20260921/experiments/audit_revision_results.py
python revision_20260921/analysis/analyze_revision.py --original-results reproducibility/results_final_ensemble --new-results revision_20260921/experiments/results/model_level_results.csv --new-predictions revision_20260921/experiments/results/trial_level_predictions.csv --output-dir revision_20260921/analysis_rerun
```

The second audit checks the stored revision outputs and writes its validation report next to them. The statistical analysis regenerates subject/seed summaries, the original three-contrast checks, seven exploratory contrasts, class summaries, and the normal-location design-sensitivity simulation. Use a new analysis output folder as above so the supplied statistical records remain unchanged.

## Obtain data and rerun training

Raw GDF and evaluation-label archives are NOT distributed here. Obtain them from the official sources and follow their conditions of use:

- [Dataset description](https://www.bbci.de/competition/iv/desc_2a.pdf)
- [GDF recordings](https://www.bbci.de/competition/download/competition_iv/BCICIV_2a_gdf.zip)
- [Official evaluation labels](https://www.bbci.de/competition/iv/results/ds2a/true_labels.zip)

Use one copy of every A01T–A09T/A01E–A09E GDF and A01E–A09E label MAT file under `data`. Never mix smoke-test output with the reportable results.

```powershell
python reproducibility/run_cross_session_benchmark.py --data-dir data --output-dir original_rerun --max-epochs 100 --patience 15 --torch-threads 4
python revision_20260921/experiments/run_revision_baselines.py --self-test --output-dir revision_self_test_rerun
python revision_20260921/experiments/run_revision_baselines.py --data-dir data --output-dir revision_rerun --threads 4
```

For the archived original experiment see `reproducibility/protocol.yaml` and `reproducibility/results_final_ensemble/run_metadata.json`. For revision conditions and exact C-selection/EA definitions see `revision_20260921/experiments/protocol.json` and its README. The revision script refuses to overwrite an existing run metadata file.

## Evidence map

- Original final results: `reproducibility/results_final_ensemble/` (27 final subject/model rows, 45 individual neural-refit rows; 20,736 total archived trial predictions including refits).
- Added experiments: `revision_20260921/experiments/results/` (36 rows; 10,368 target predictions; 1,080 validation C scores; saved fold membership, settings and EA references).
- Combined analysis: `revision_20260921/analysis/` (81 subject/condition summary rows, including descriptive neural seed-mean and first-seed conditions).
- Literature verification: `revision_20260921/literature.md`.
- SHA-256 manifest: `SHA256SUMS.json`, recording the byte-level content of every included file other than the manifest itself.

## Interpretation and release boundaries

The revision was performed after the original evaluation outcomes were known. It is exploratory, not prospectively preregistered. EA fits a reference from all unlabeled target-session signals and is batch-transductive, unlike source-only fitting. Each EA pipeline separately reselects C. Neither the training search nor the model-family coverage is exhaustive. No seed, trial or fold is counted as an additional participant.

The author initially supplied [another author's GitHub project](https://github.com/gabfarmarcondes/Motor-Imagery-BCI) as background. That address is not this study's public code release, and that repository is not bundled here.

No raw EEG or third-party package binaries are included. Dataset, library, template and cited algorithm rights remain with their respective owners. The author has not yet selected a public software license or deposited this package; this supplement does not itself grant a new open-source license. Review licensing and data-use conditions before public upload, then add the real accessible URL/DOI to the manuscript. No upload, manuscript submission, registration or payment was performed in this revision task.
