"""Independently validate the reportable v1.1 benchmark-result directory.

This does not re-run a decoder or alter a result file.  It checks the
participant-, model-, and trial-level invariants that the submission relies on
and writes a compact JSON report for the accompanying material.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


FINAL_MODELS = {
    "FBCSP-SVM",
    "LE-TS-LR",
    "EEGNet (5-seed probability ensemble)",
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    results_dir = args.results_dir
    manifest = pd.read_csv(results_dir / "dataset_manifest.csv")
    model = pd.read_csv(results_dir / "model_level_results.csv")
    subject_summary = pd.read_csv(results_dir / "subject_level_summary.csv")
    statistics = pd.read_csv(results_dir / "primary_macro_f1_statistics.csv")
    predictions = pd.read_csv(results_dir / "trial_level_predictions.csv")
    selections = pd.read_csv(results_dir / "eegnet_loro_selection.csv")
    seed_results = pd.read_csv(results_dir / "eegnet_seed_level_results.csv")

    expected_subjects = {f"A{i:02d}" for i in range(1, 10)}
    require(set(manifest["subject"]) == expected_subjects and len(manifest) == 9, "Dataset manifest must contain A01–A09 exactly once")
    for column, expected in {
        "train_trials": 288,
        "test_trials": 288,
        "channels": 22,
        "samples_per_epoch": 501,
    }.items():
        require((manifest[column] == expected).all(), f"Unexpected {column} in dataset manifest")
    for column in ("train_class_counts", "test_class_counts"):
        require(manifest[column].apply(lambda value: json.loads(value) == [72, 72, 72, 72]).all(), f"Unexpected {column} in dataset manifest")
    for column in ("train_run_counts", "test_run_counts"):
        require(manifest[column].apply(lambda value: json.loads(value) == [48, 48, 48, 48, 48, 48]).all(), f"Unexpected {column} in dataset manifest")

    require(len(model) == 27 and not model.duplicated(["subject", "model"]).any(), "Final model table must have 27 unique subject/model rows")
    require(set(model["model"]) == FINAL_MODELS, "Unexpected final model labels")
    require(model.groupby("model")["subject"].nunique().eq(9).all(), "Each final model must cover all nine participants")
    metrics = ["accuracy", "balanced_accuracy", "macro_f1", "kappa"]
    require(np.isfinite(model[metrics].to_numpy(dtype=float)).all(), "Model metrics contain non-finite values")
    require(((model[metrics] >= -1.0) & (model[metrics] <= 1.0)).all().all(), "Model metrics fall outside valid bounds")

    calculated = model.groupby("model")[metrics].agg(["mean", "std"])
    summary_by_model = subject_summary.set_index("model")
    require(set(summary_by_model.index) == FINAL_MODELS, "Summary model labels do not match final model labels")
    for decoder in FINAL_MODELS:
        for metric in metrics:
            require(np.isclose(calculated.loc[decoder, (metric, "mean")], summary_by_model.loc[decoder, f"{metric}_mean"]), f"Summary mean mismatch for {decoder} {metric}")
            require(np.isclose(calculated.loc[decoder, (metric, "std")], summary_by_model.loc[decoder, f"{metric}_std"]), f"Summary SD mismatch for {decoder} {metric}")

    expected_pairs = {
        frozenset(("FBCSP-SVM", "LE-TS-LR")),
        frozenset(("FBCSP-SVM", "EEGNet (5-seed probability ensemble)")),
        frozenset(("LE-TS-LR", "EEGNet (5-seed probability ensemble)")),
    }
    observed_pairs = {frozenset((row.model_a, row.model_b)) for row in statistics.itertuples()}
    require(len(statistics) == 3 and observed_pairs == expected_pairs, "Primary statistics must contain each final-model pair exactly once")
    require(np.isfinite(statistics.select_dtypes(include=[np.number]).to_numpy()).all(), "Statistics contain non-finite values")

    final_predictions = predictions[predictions["model"].isin(FINAL_MODELS)].copy()
    require(len(final_predictions) == 9 * 3 * 288, "Expected one final prediction per held-out trial and final model")
    require(not final_predictions.duplicated(["subject", "model", "trial_index"]).any(), "Duplicate final trial predictions found")
    require(set(final_predictions["subject"]) == expected_subjects, "Final predictions lack a participant")
    require(final_predictions.groupby(["subject", "model"]).size().eq(288).all(), "Final prediction trial count mismatch")
    for column in ("true_class", "predicted_class"):
        require(final_predictions[column].isin([0, 1, 2, 3]).all(), f"Invalid class in {column}")

    require(len(selections) == 9 * 6 and selections.groupby("subject").size().eq(6).all(), "Expected six source-session LORO folds per participant")
    require(len(seed_results) == 9 * 5 and seed_results.groupby("subject").size().eq(5).all(), "Expected five EEGNet refits per participant")

    report = {
        "status": "PASS",
        "participants": 9,
        "final_model_rows": int(len(model)),
        "final_prediction_rows": int(len(final_predictions)),
        "seed_stability_rows": int(len(seed_results)),
        "source_loro_rows": int(len(selections)),
        "models": sorted(FINAL_MODELS),
        "primary_metric": "macro_f1",
        "summary": subject_summary.to_dict(orient="records"),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
