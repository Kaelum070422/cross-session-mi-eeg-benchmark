# Evaluation-Session Label Handling Clarification

The BCI Competition IV-2a evaluation labels are public.  In the frozen v1.1
runner, the AxxE labels are loaded with the signal file so that the script can
assert the official four-class, 288-trial, 72-trials-per-class layout and can
compute the final held-out metrics after prediction.

They are **not** passed to preprocessing parameter estimation, feature
selection, covariance-reference estimation, validation, epoch selection,
model fitting, or ensemble construction.  All such data-dependent operations
use AxxT and its labels only.  This is therefore a pipeline-level
source-session-to-target-session evaluation, not a newly blind test.

This note clarifies the compact wording in `protocol.yaml` ("only for final
scoring and the saved prediction manifest").  The run metadata intentionally
retains the exact pre-run configuration hash; this explanatory note does not
alter that frozen configuration.
