# Experiment Change Log

## Final analysis v1.1 — before the reportable all-subject run

A preliminary, non-reporting execution was halted after completing the first
participant. Its sole purpose was to validate data parsing and runtime. Its
evaluation-session results are not included in any result table, figure,
statistical test, or manuscript conclusion.

Before restarting the all-subject run, a source-code audit identified and
corrected the following implementation issues. These changes were motivated by
auditability and reproducibility, not by the preliminary metric values:

1. The FBCSP mutual-information feature selector now receives the declared
   deterministic `random_state`; it can no longer inherit global NumPy state
   from a preceding neural-network fit.
2. The final EEGNet is now explicitly defined as a five-fixed-seed,
   mean-softmax-probability ensemble. The script saves both individual-refit
   results (for stability reporting) and exactly one ensemble prediction per
   held-out E-session trial (for the main comparison).
3. The tangent-space baseline now uses a standard log-Euclidean coordinate
   map, `log(C) - log(G)`, around a T-session-only log-Euclidean reference.
4. The command defaults, documentation, and implementation now agree on 100
   epochs and early-stopping patience 15; the epoch window is consistently
   documented as 0.5–2.5 s after cue onset.
5. The final run saves per-trial manifests and predictions, code/protocol
   SHA-256 values, complete fixed model settings, and hard assertions for the
   official 288-trial, 72-per-class, six-run layout.

The partial files in `results/` are retained only as an aborted pilot record.
The reportable run is written to `results_final_ensemble/` and is never merged
with the pilot output.
