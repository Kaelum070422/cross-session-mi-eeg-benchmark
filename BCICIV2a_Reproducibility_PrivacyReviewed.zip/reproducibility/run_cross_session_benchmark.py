"""Reproducible cross-session benchmark on BCI Competition IV data set 2a.

This script intentionally keeps the test session isolated from every fitted
operation. It compares a filter-bank CSP + linear SVM baseline, a
log-Euclidean tangent-space logistic-regression baseline, and EEGNet. For
each of the nine participants, the official T session is split into a model
development subset and a validation subset; the official E session is used
exactly once for final evaluation.

The experiment is an offline decoding benchmark. It does not make a claim
about online BCI performance or clinical utility.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import itertools
import json
import math
import os
import platform
import random
import sys
import urllib.request
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from functools import partial
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mne
import numpy as np
import pandas as pd
import scipy
from scipy import linalg, signal
from scipy.io import loadmat
from scipy.stats import rankdata, wilcoxon
from sklearn.covariance import LedoitWolf
from sklearn.feature_selection import SelectKBest, mutual_info_classif
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    cohen_kappa_score,
    confusion_matrix,
    f1_score,
)
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
import sklearn
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset


GDF_URL = "https://www.bbci.de/competition/download/competition_iv/BCICIV_2a_gdf.zip"
LABEL_URL = "https://www.bbci.de/competition/iv/results/ds2a/true_labels.zip"
SUBJECTS = tuple(f"A{i:02d}" for i in range(1, 10))
CLASS_NAMES = ("Left hand", "Right hand", "Feet", "Tongue")
FS = 250
EPOCH_TMIN = 0.5
EPOCH_TMAX = 2.5
BANDS = ((4, 8), (8, 12), (12, 16), (16, 20), (20, 24), (24, 28), (28, 32), (32, 36))
EEGNET_MODEL_NAME = "EEGNet (5-seed probability ensemble)"


@dataclass(frozen=True)
class RunConfig:
    data_dir: str
    output_dir: str
    seeds: tuple[int, ...]
    max_epochs: int
    patience: int
    batch_size: int
    learning_rate: float
    weight_decay: float
    torch_threads: int
    device: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, required=True, help="Directory holding raw/extracted BCIC IV 2a files.")
    parser.add_argument("--output-dir", type=Path, required=True, help="Directory for result tables and figures.")
    parser.add_argument("--download", action="store_true", help="Download official raw GDF and label archives if absent.")
    parser.add_argument("--subjects", nargs="+", choices=SUBJECTS, default=list(SUBJECTS), help="Participant IDs; use a subset only for a smoke test.")
    parser.add_argument("--seeds", type=int, nargs="+", default=[20261, 20262, 20263, 20264, 20265])
    parser.add_argument("--max-epochs", type=int, default=100)
    parser.add_argument("--patience", type=int, default=15)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--torch-threads", type=int, default=4)
    parser.add_argument("--device", choices=["cpu"], default="cpu")
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def download_file(url: str, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    print(f"Downloading {url} -> {destination}", flush=True)
    urllib.request.urlretrieve(url, destination)


def ensure_data(data_dir: Path, allow_download: bool) -> tuple[Path, Path]:
    """Return roots containing GDF files and official evaluation labels."""
    data_dir.mkdir(parents=True, exist_ok=True)
    gdf_archive = data_dir / "BCICIV_2a_gdf.zip"
    labels_archive = data_dir / "true_labels.zip"
    gdf_files = list(data_dir.rglob("A??T.gdf"))
    label_files = list(data_dir.rglob("A??E.mat"))

    if not gdf_files:
        if not gdf_archive.exists():
            if not allow_download:
                raise FileNotFoundError("Missing GDF archive. Re-run with --download or place the official archive in --data-dir.")
            download_file(GDF_URL, gdf_archive)
        print(f"Extracting {gdf_archive}", flush=True)
        with zipfile.ZipFile(gdf_archive) as archive:
            archive.extractall(data_dir / "gdf")
        gdf_files = list(data_dir.rglob("A??T.gdf"))

    if not label_files:
        if not labels_archive.exists():
            if not allow_download:
                raise FileNotFoundError("Missing true-label archive. Re-run with --download or place it in --data-dir.")
            download_file(LABEL_URL, labels_archive)
        print(f"Extracting {labels_archive}", flush=True)
        with zipfile.ZipFile(labels_archive) as archive:
            archive.extractall(data_dir / "true_labels")
        label_files = list(data_dir.rglob("A??E.mat"))

    if len(gdf_files) != 9 or len(label_files) != 9:
        raise RuntimeError(
            f"Expected 9 T-session GDF files and 9 E-session label files; found {len(gdf_files)} and {len(label_files)}."
        )
    return data_dir, data_dir


def find_file(root: Path, filename: str) -> Path:
    matches = sorted(root.rglob(filename))
    if len(matches) != 1:
        raise FileNotFoundError(f"Expected one {filename} under {root}, found {len(matches)}")
    return matches[0]


def load_evaluation_labels(path: Path) -> np.ndarray:
    contents = loadmat(path)
    candidates: list[np.ndarray] = []
    for key, value in contents.items():
        if key.startswith("__") or not isinstance(value, np.ndarray) or not np.issubdtype(value.dtype, np.number):
            continue
        flat = np.asarray(value).squeeze().astype(int)
        if flat.ndim == 1 and flat.size == 288 and set(np.unique(flat)).issubset({1, 2, 3, 4}):
            candidates.append(flat)
    if len(candidates) != 1:
        raise ValueError(f"Could not uniquely locate 288 class labels in {path}")
    return candidates[0] - 1


def _event_code(event_id: dict[str, int], original_code: int) -> int:
    key = str(original_code)
    if key not in event_id:
        raise KeyError(f"Missing event code {original_code}; available annotations: {sorted(event_id)}")
    return event_id[key]


def _run_ids(events: np.ndarray, event_id: dict[str, int], epoch_events: np.ndarray) -> np.ndarray:
    """Recover the six official run identifiers for each selected cue event."""
    start_code = _event_code(event_id, 32766)
    starts = events[events[:, 2] == start_code, 0]
    # T sessions have three preceding EOG-recording blocks that also carry a
    # run-start marker. The actual six MI runs are the final six starts; E
    # sessions already contain only those six markers.
    starts = starts[-6:]
    if len(starts) != 6:
        raise RuntimeError(f"Expected at least six run-start events, found {len(starts)}")
    run_ids = np.searchsorted(starts, epoch_events[:, 0], side="right")
    if not set(np.unique(run_ids)).issubset(set(range(1, 7))):
        raise RuntimeError("Could not assign selected epochs to the six recording runs")
    return run_ids.astype(np.int64)


def load_session(gdf_path: Path, session: str, eval_labels: np.ndarray | None = None) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Load one session and epoch the fixed 0.5-2.5 s post-cue interval.

    The raw session is filtered separately with a fixed 4-38 Hz FIR filter. No
    data-dependent transform is fitted jointly across T and E sessions.
    """
    raw = mne.io.read_raw_gdf(gdf_path, preload=True, verbose="ERROR")
    if len(raw.ch_names) < 25:
        raise RuntimeError(f"Unexpected channel count in {gdf_path}: {len(raw.ch_names)}")
    raw.pick(raw.ch_names[:22])  # Dataset specification: first 22 channels are EEG; last 3 are EOG.
    raw.filter(4.0, 38.0, method="fir", phase="zero", verbose="ERROR")
    events, event_id = mne.events_from_annotations(raw, verbose="ERROR")

    if session == "T":
        code_to_label = {_event_code(event_id, 769 + class_id): class_id for class_id in range(4)}
        epochs = mne.Epochs(
            raw,
            events,
            event_id={str(code): code for code in code_to_label},
            tmin=EPOCH_TMIN,
            tmax=EPOCH_TMAX,
            baseline=None,
            preload=True,
            reject_by_annotation=False,
            verbose="ERROR",
        )
        y = np.asarray([code_to_label[code] for code in epochs.events[:, 2]], dtype=np.int64)
    elif session == "E":
        code = _event_code(event_id, 783)
        epochs = mne.Epochs(
            raw,
            events,
            event_id={"783": code},
            tmin=EPOCH_TMIN,
            tmax=EPOCH_TMAX,
            baseline=None,
            preload=True,
            reject_by_annotation=False,
            verbose="ERROR",
        )
        if eval_labels is None:
            raise ValueError("Evaluation labels are required for E sessions")
        y = np.asarray(eval_labels, dtype=np.int64)
    else:
        raise ValueError(f"Unknown session: {session}")

    x = epochs.get_data(copy=True) * 1e6  # microvolts; scaling is documented and applied per session.
    if len(x) != len(y):
        raise RuntimeError(f"Epoch/label mismatch in {gdf_path}: {len(x)} epochs vs {len(y)} labels")
    if x.shape[1] != 22:
        raise RuntimeError(f"Expected 22 EEG channels, found {x.shape[1]}")
    return x.astype(np.float32), y, _run_ids(events, event_id, epochs.events)


def normalized_covariance(epoch: np.ndarray) -> np.ndarray:
    covariance = epoch @ epoch.T
    return covariance / max(float(np.trace(covariance)), np.finfo(float).eps)


class FBCSPSVM:
    """One-vs-rest filter-bank CSP with mutual-information feature selection."""

    def __init__(self, bands: tuple[tuple[int, int], ...] = BANDS, pairs: int = 2, k_features: int = 20, random_state: int = 0):
        self.bands = bands
        self.pairs = pairs
        self.k_features = k_features
        self.random_state = random_state
        self.sos_filters: list[np.ndarray] = []
        self.csp_filters: list[list[np.ndarray]] = []

    @staticmethod
    def _bandpass(x: np.ndarray, sos: np.ndarray) -> np.ndarray:
        return signal.sosfiltfilt(sos, x, axis=-1).astype(np.float64, copy=False)

    def _fit_csp(self, x: np.ndarray, y: np.ndarray, target: int) -> np.ndarray:
        positive = np.mean([normalized_covariance(epoch) for epoch in x[y == target]], axis=0)
        negative = np.mean([normalized_covariance(epoch) for epoch in x[y != target]], axis=0)
        values, vectors = linalg.eigh(positive, positive + negative, check_finite=False)
        selected = np.r_[np.arange(self.pairs), np.arange(len(values) - self.pairs, len(values))]
        return vectors[:, selected].T

    def _features(self, x: np.ndarray) -> np.ndarray:
        features: list[np.ndarray] = []
        for sos, filters_for_band in zip(self.sos_filters, self.csp_filters, strict=True):
            band_data = self._bandpass(x, sos)
            for filters in filters_for_band:
                projected = np.einsum("kc,nct->nkt", filters, band_data, optimize=True)
                variances = np.var(projected, axis=-1)
                normalized = variances / np.maximum(variances.sum(axis=1, keepdims=True), np.finfo(float).eps)
                features.append(np.log(np.maximum(normalized, np.finfo(float).eps)))
        return np.concatenate(features, axis=1)

    def fit(self, x: np.ndarray, y: np.ndarray) -> "FBCSPSVM":
        self.sos_filters = []
        self.csp_filters = []
        for low, high in self.bands:
            sos = signal.butter(4, [low, high], btype="bandpass", fs=FS, output="sos")
            band_data = self._bandpass(x, sos)
            self.sos_filters.append(sos)
            self.csp_filters.append([self._fit_csp(band_data, y, target) for target in range(4)])
        all_features = self._features(x)
        # Mutual-information estimation adds infinitesimal noise when continuous
        # variables contain ties. Bind the declared state explicitly so that this
        # baseline does not inherit the global NumPy state of an earlier model.
        self.selector = SelectKBest(
            partial(mutual_info_classif, random_state=self.random_state),
            k=min(self.k_features, all_features.shape[1]),
        )
        selected = self.selector.fit_transform(all_features, y)
        self.scaler = StandardScaler().fit(selected)
        self.classifier = SVC(kernel="linear", C=1.0, decision_function_shape="ovr")
        self.classifier.fit(self.scaler.transform(selected), y)
        return self

    def predict(self, x: np.ndarray) -> np.ndarray:
        features = self._features(x)
        selected = self.selector.transform(features)
        return self.classifier.predict(self.scaler.transform(selected))


def _matrix_log_spd(matrix: np.ndarray) -> np.ndarray:
    values, vectors = np.linalg.eigh(matrix)
    values = np.clip(values, 1e-12, None)
    return (vectors * np.log(values)) @ vectors.T


def _matrix_exp_sym(matrix: np.ndarray) -> np.ndarray:
    values, vectors = np.linalg.eigh(matrix)
    return (vectors * np.exp(values)) @ vectors.T


def _matrix_inverse_sqrt(matrix: np.ndarray) -> np.ndarray:
    values, vectors = np.linalg.eigh(matrix)
    values = np.clip(values, 1e-12, None)
    return (vectors * (values ** -0.5)) @ vectors.T


class LETSLR:
    """Log-Euclidean tangent-space logistic regression baseline."""

    @staticmethod
    def _covariances(x: np.ndarray) -> np.ndarray:
        return np.stack([LedoitWolf().fit(epoch.T).covariance_ for epoch in x])

    def _tangent_features(self, covariances: np.ndarray) -> np.ndarray:
        # Log-Euclidean tangent coordinates: log(C) - log(G), where G is the
        # log-Euclidean reference fitted on the T-session only.
        logged = np.stack([_matrix_log_spd(matrix) for matrix in covariances]) - self.log_reference
        row, col = np.triu_indices(logged.shape[1])
        values = logged[:, row, col]
        values[:, row != col] *= math.sqrt(2.0)
        return values

    def fit(self, x: np.ndarray, y: np.ndarray) -> "LETSLR":
        covariances = self._covariances(x)
        self.log_reference = np.mean(np.stack([_matrix_log_spd(matrix) for matrix in covariances]), axis=0)
        features = self._tangent_features(covariances)
        self.scaler = StandardScaler().fit(features)
        self.classifier = LogisticRegression(C=1.0, solver="lbfgs", max_iter=5000, random_state=0)
        self.classifier.fit(self.scaler.transform(features), y)
        return self

    def predict(self, x: np.ndarray) -> np.ndarray:
        features = self._tangent_features(self._covariances(x))
        return self.classifier.predict(self.scaler.transform(features))


class EEGNet(nn.Module):
    """Compact EEGNet-v4-style implementation with adaptive temporal pooling."""

    def __init__(self, channels: int, classes: int = 4, f1: int = 8, depth_multiplier: int = 2, f2: int = 16, dropout: float = 0.5):
        super().__init__()
        self.temporal = nn.Sequential(
            nn.Conv2d(1, f1, kernel_size=(1, 64), padding=(0, 32), bias=False),
            nn.BatchNorm2d(f1),
        )
        self.spatial = nn.Sequential(
            nn.Conv2d(f1, f1 * depth_multiplier, kernel_size=(channels, 1), groups=f1, bias=False),
            nn.BatchNorm2d(f1 * depth_multiplier),
            nn.ELU(),
            nn.AvgPool2d(kernel_size=(1, 4)),
            nn.Dropout(dropout),
        )
        self.separable = nn.Sequential(
            nn.Conv2d(f1 * depth_multiplier, f1 * depth_multiplier, kernel_size=(1, 16), padding=(0, 8), groups=f1 * depth_multiplier, bias=False),
            nn.Conv2d(f1 * depth_multiplier, f2, kernel_size=(1, 1), bias=False),
            nn.BatchNorm2d(f2),
            nn.ELU(),
            nn.AvgPool2d(kernel_size=(1, 8)),
            nn.Dropout(dropout),
            nn.AdaptiveAvgPool2d((1, 1)),
        )
        self.classifier = nn.Linear(f2, classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.temporal(x)
        x = self.spatial(x)
        x = self.separable(x)
        return self.classifier(x.flatten(1))


def set_seed(seed: int, torch_threads: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(torch_threads)
    torch.use_deterministic_algorithms(True, warn_only=True)


def fit_standardizer(x_train: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    mean = x_train.mean(axis=(0, 2), keepdims=True)
    std = x_train.std(axis=(0, 2), keepdims=True)
    return mean.astype(np.float32), np.maximum(std, 1e-6).astype(np.float32)


def model_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "kappa": float(cohen_kappa_score(y_true, y_pred)),
    }


def assert_session_integrity(
    x: np.ndarray, y: np.ndarray, run_ids: np.ndarray, subject: str, session: str
) -> None:
    """Fail closed if a source file no longer matches the official 2a layout."""
    expected_trials = 288
    expected_classes = np.full(4, 72)
    expected_runs = np.full(6, 48)
    class_counts = np.bincount(y, minlength=4)
    run_counts = np.bincount(run_ids, minlength=7)[1:]
    if len(x) != expected_trials or len(y) != expected_trials or len(run_ids) != expected_trials:
        raise RuntimeError(f"{subject}{session}: expected {expected_trials} trials")
    if not np.array_equal(class_counts, expected_classes):
        raise RuntimeError(f"{subject}{session}: unexpected class counts {class_counts.tolist()}")
    if not np.array_equal(run_counts, expected_runs):
        raise RuntimeError(f"{subject}{session}: unexpected run counts {run_counts.tolist()}")


def make_trial_prediction_rows(
    subject: str,
    model: str,
    seed: str | int,
    y_true: np.ndarray,
    y_pred: np.ndarray,
    run_ids: np.ndarray,
) -> list[dict[str, Any]]:
    """Create a compact, auditable prediction manifest for every E-session trial."""
    return [
        {
            "subject": subject,
            "model": model,
            "seed": seed,
            "trial_index": int(index + 1),
            "evaluation_run": int(run_ids[index]),
            "true_class": int(y_true[index]),
            "predicted_class": int(y_pred[index]),
        }
        for index in range(len(y_true))
    ]


def train_eegnet(
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_val: np.ndarray,
    y_val: np.ndarray,
    x_test: np.ndarray,
    seed: int,
    config: RunConfig,
) -> tuple[np.ndarray, int, float]:
    set_seed(seed, config.torch_threads)
    mean, std = fit_standardizer(x_train)
    train_tensor = torch.tensor(((x_train - mean) / std)[:, None, :, :], dtype=torch.float32)
    val_tensor = torch.tensor(((x_val - mean) / std)[:, None, :, :], dtype=torch.float32)
    test_tensor = torch.tensor(((x_test - mean) / std)[:, None, :, :], dtype=torch.float32)
    train_labels = torch.tensor(y_train, dtype=torch.long)
    val_labels = torch.tensor(y_val, dtype=torch.long)
    generator = torch.Generator().manual_seed(seed)
    loader = DataLoader(TensorDataset(train_tensor, train_labels), batch_size=config.batch_size, shuffle=True, generator=generator, num_workers=0)
    device = torch.device(config.device)
    model = EEGNet(channels=x_train.shape[1]).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay)
    criterion = nn.CrossEntropyLoss()
    best_state: dict[str, torch.Tensor] | None = None
    best_val_loss = float("inf")
    best_epoch = 0
    no_improvement = 0

    for epoch in range(1, config.max_epochs + 1):
        model.train()
        for features, labels in loader:
            features, labels = features.to(device), labels.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = criterion(model(features), labels)
            loss.backward()
            optimizer.step()
        model.eval()
        with torch.no_grad():
            val_logits = model(val_tensor.to(device))
            val_loss = float(criterion(val_logits, val_labels.to(device)).item())
        if val_loss < best_val_loss - 1e-7:
            best_val_loss = val_loss
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
            no_improvement = 0
        else:
            no_improvement += 1
            if no_improvement >= config.patience:
                break

    if best_state is None:
        raise RuntimeError("EEGNet failed to produce a validation checkpoint")
    model.load_state_dict(best_state)
    model.eval()
    with torch.no_grad():
        predictions = model(test_tensor.to(device)).argmax(dim=1).cpu().numpy()
    return predictions.astype(np.int64), best_epoch, best_val_loss


def train_eegnet_for_fixed_epochs(
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_test: np.ndarray,
    seed: int,
    epochs: int,
    config: RunConfig,
) -> tuple[np.ndarray, np.ndarray]:
    """Refit EEGNet on all calibration-session trials after T-only selection."""
    set_seed(seed, config.torch_threads)
    mean, std = fit_standardizer(x_train)
    train_tensor = torch.tensor(((x_train - mean) / std)[:, None, :, :], dtype=torch.float32)
    test_tensor = torch.tensor(((x_test - mean) / std)[:, None, :, :], dtype=torch.float32)
    train_labels = torch.tensor(y_train, dtype=torch.long)
    generator = torch.Generator().manual_seed(seed)
    loader = DataLoader(TensorDataset(train_tensor, train_labels), batch_size=config.batch_size, shuffle=True, generator=generator, num_workers=0)
    device = torch.device(config.device)
    model = EEGNet(channels=x_train.shape[1]).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay)
    criterion = nn.CrossEntropyLoss()
    model.train()
    for _ in range(epochs):
        for features, labels in loader:
            features, labels = features.to(device), labels.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = criterion(model(features), labels)
            loss.backward()
            optimizer.step()
    model.eval()
    with torch.no_grad():
        probabilities = torch.softmax(model(test_tensor.to(device)), dim=1).cpu().numpy()
    predictions = probabilities.argmax(axis=1)
    return predictions.astype(np.int64), probabilities.astype(np.float64)


def select_eegnet_epoch_by_run(
    x_train: np.ndarray,
    y_train: np.ndarray,
    run_ids: np.ndarray,
    subject_index: int,
    config: RunConfig,
) -> tuple[int, pd.DataFrame]:
    """Use leave-one-run-out validation within T, never inspecting E.

    The median best epoch from the six temporally separated validation runs is
    used for the final full-T fits. The validation predictions are deliberately
    not reported as final performance.
    """
    rows: list[dict[str, Any]] = []
    for run in sorted(np.unique(run_ids)):
        dev_index = np.where(run_ids != run)[0]
        val_index = np.where(run_ids == run)[0]
        selection_seed = 100_000 + subject_index * 100 + int(run)
        _, best_epoch, val_loss = train_eegnet(
            x_train[dev_index],
            y_train[dev_index],
            x_train[val_index],
            y_train[val_index],
            x_train[val_index],
            selection_seed,
            config,
        )
        rows.append({"held_out_train_run": int(run), "best_epoch": best_epoch, "validation_loss": val_loss})
    table = pd.DataFrame(rows)
    return int(np.median(table["best_epoch"])), table


def exact_sign_flip_pvalue(delta: np.ndarray) -> float:
    """Two-sided exact sign-flip test over the nine participant-level effects."""
    delta = np.asarray(delta, dtype=float)
    observed = abs(float(delta.mean()))
    null = np.asarray([abs(float((np.asarray(signs) * delta).mean())) for signs in itertools.product((-1, 1), repeat=len(delta))])
    return float(np.mean(null >= observed - 1e-15))


def bootstrap_mean_ci(delta: np.ndarray, seed: int = 20260915, draws: int = 20_000) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    delta = np.asarray(delta, dtype=float)
    resamples = rng.choice(delta, size=(draws, len(delta)), replace=True).mean(axis=1)
    low, high = np.quantile(resamples, [0.025, 0.975])
    return float(low), float(high)


def holm_adjust(pvalues: list[float]) -> list[float]:
    order = np.argsort(pvalues)
    adjusted = np.empty(len(pvalues), dtype=float)
    running = 0.0
    total = len(pvalues)
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (total - rank) * pvalues[index]))
        adjusted[index] = running
    return adjusted.tolist()


def write_statistics(long_results: pd.DataFrame, output_dir: Path) -> pd.DataFrame:
    subject_means = long_results.groupby(["subject", "model"], as_index=False)[["accuracy", "balanced_accuracy", "macro_f1", "kappa"]].mean()
    subject_means.to_csv(output_dir / "subject_level_means.csv", index=False)
    models = sorted(subject_means["model"].unique())
    comparisons: list[dict[str, Any]] = []
    for left, right in itertools.combinations(models, 2):
        pivot = subject_means.pivot(index="subject", columns="model", values="macro_f1")
        delta = (pivot[left] - pivot[right]).to_numpy()
        ci_low, ci_high = bootstrap_mean_ci(delta)
        sd = float(np.std(delta, ddof=1))
        nonzero = delta[np.abs(delta) > 1e-12]
        if len(nonzero):
            signed_ranks = rankdata(np.abs(nonzero)) * np.sign(nonzero)
            rank_biserial = float(signed_ranks.sum() / (len(nonzero) * (len(nonzero) + 1) / 2))
            wilcoxon_result = wilcoxon(delta, alternative="two-sided", method="auto")
            wilcoxon_statistic = float(wilcoxon_result.statistic)
            wilcoxon_p = float(wilcoxon_result.pvalue)
        else:
            rank_biserial = 0.0
            wilcoxon_statistic = 0.0
            wilcoxon_p = 1.0
        comparisons.append(
            {
                "metric": "macro_f1",
                "model_a": left,
                "model_b": right,
                "n_subjects": len(delta),
                "mean_difference_a_minus_b": float(delta.mean()),
                "bootstrap_95ci_low": ci_low,
                "bootstrap_95ci_high": ci_high,
                "cohens_dz": float(delta.mean() / sd) if sd > 0 else float("nan"),
                "wilcoxon_statistic": wilcoxon_statistic,
                "wilcoxon_p": wilcoxon_p,
                "rank_biserial": rank_biserial,
                "exact_sign_flip_p": exact_sign_flip_pvalue(delta),
            }
        )
    if comparisons:
        adjusted = holm_adjust([row["wilcoxon_p"] for row in comparisons])
        for row, p_adjusted in zip(comparisons, adjusted, strict=True):
            row["holm_adjusted_p"] = p_adjusted
    table = pd.DataFrame(comparisons)
    table.to_csv(output_dir / "primary_macro_f1_statistics.csv", index=False)
    return subject_means


def draw_subject_figure(subject_means: pd.DataFrame, output_dir: Path) -> None:
    pivot = subject_means.pivot(index="subject", columns="model", values="macro_f1").sort_index()
    ax = pivot.plot(kind="bar", figsize=(9.2, 4.6), width=0.78, color=["#4C78A8", "#F58518", "#54A24B"])
    ax.set_xlabel("Participant")
    ax.set_ylabel("Cross-session macro F1")
    ax.set_ylim(0, 1)
    ax.grid(axis="y", color="#D9D9D9", linewidth=0.8)
    ax.set_axisbelow(True)
    ax.legend(title="Model", frameon=False, ncol=3, loc="upper center", bbox_to_anchor=(0.5, 1.18))
    plt.tight_layout()
    plt.savefig(output_dir / "figure_subject_macro_f1.png", dpi=300, bbox_inches="tight")
    plt.savefig(output_dir / "figure_subject_macro_f1.pdf", bbox_inches="tight")
    plt.close()


def draw_confusion_figures(confusions: dict[str, np.ndarray], output_dir: Path) -> None:
    for model, matrix in confusions.items():
        normalised = matrix / np.maximum(matrix.sum(axis=1, keepdims=True), 1)
        fig, ax = plt.subplots(figsize=(4.3, 3.7))
        image = ax.imshow(normalised, cmap="Blues", vmin=0, vmax=1)
        for row in range(4):
            for column in range(4):
                value = normalised[row, column]
                ax.text(column, row, f"{value:.2f}", ha="center", va="center", color="white" if value > 0.55 else "black")
        ax.set_xticks(range(4), CLASS_NAMES, rotation=25, ha="right")
        ax.set_yticks(range(4), CLASS_NAMES)
        ax.set_xlabel("Predicted class")
        ax.set_ylabel("True class")
        ax.set_title(f"Aggregated cross-session confusion: {model}")
        fig.colorbar(image, ax=ax, fraction=0.045, pad=0.04, label="Row-normalised proportion")
        fig.tight_layout()
        stem = model.lower().replace("-", "_").replace(" ", "_")
        fig.savefig(output_dir / f"confusion_{stem}.png", dpi=300, bbox_inches="tight")
        plt.close(fig)


def write_summary(subject_means: pd.DataFrame, output_dir: Path) -> None:
    summary = subject_means.groupby("model")[["accuracy", "balanced_accuracy", "macro_f1", "kappa"]].agg(["mean", "std", "median"])
    summary.columns = ["_".join(column) for column in summary.columns]
    summary.reset_index().to_csv(output_dir / "subject_level_summary.csv", index=False)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    gdf_root, label_root = ensure_data(args.data_dir, args.download)
    config = RunConfig(
        data_dir=str(args.data_dir.resolve()),
        output_dir=str(args.output_dir.resolve()),
        seeds=tuple(args.seeds),
        max_epochs=args.max_epochs,
        patience=args.patience,
        batch_size=args.batch_size,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        torch_threads=args.torch_threads,
        device=args.device,
    )
    metadata: dict[str, Any] = {
        "run_config": asdict(config),
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version,
        "platform": platform.platform(),
        "packages": {
            "mne": mne.__version__,
            "numpy": np.__version__,
            "scipy": scipy.__version__,
            "scikit_learn": sklearn.__version__,
            "pandas": pd.__version__,
            "torch": torch.__version__,
        },
        "data_source": {"gdf_archive": GDF_URL, "evaluation_labels": LABEL_URL},
        "subjects": args.subjects,
        "protocol": {
            "train_session": "AxxT",
            "test_session": "AxxE",
            "channels": 22,
            "classes": list(CLASS_NAMES),
            "epoch_seconds_post_cue": [EPOCH_TMIN, EPOCH_TMAX],
            "session_filter": {"method": "fir", "phase": "zero", "band_hz": [4, 38]},
            "artifact_policy": "No data-dependent rejection; EOG channels excluded from classification.",
        },
        "models": {
            "FBCSP-SVM": {
                "bands_hz": [list(band) for band in BANDS],
                "one_vs_rest": True,
                "csp_pairs_per_class": 2,
                "mutual_information_features": 20,
                "mutual_information_random_state": "participant index",
                "classifier": "linear SVM, C=1.0",
            },
            "LE-TS-LR": {
                "covariance": "LedoitWolf",
                "reference": "log-Euclidean mean fitted on T only",
                "coordinates": "log(C) - log(G), upper-triangular off-diagonal scaled by sqrt(2)",
                "classifier": "logistic regression, lbfgs, C=1.0, max_iter=5000, random_state=0",
            },
            EEGNET_MODEL_NAME: {
                "architecture": "EEGNet-style: F1=8, depth_multiplier=2, F2=16, temporal_kernel=64, dropout=0.5",
                "optimizer": "AdamW",
                "final_epoch_rule": "median of six leave-one-T-run-out selected epochs",
                "fixed_seeds": list(config.seeds),
                "final_prediction": "arithmetic mean of five softmax probability vectors followed by argmax",
            },
        },
    }
    script_path = Path(__file__).resolve()
    protocol_path = script_path.with_name("protocol.yaml")
    metadata["analysis_files_sha256"] = {"run_cross_session_benchmark.py": sha256(script_path)}
    if protocol_path.exists():
        metadata["analysis_files_sha256"]["protocol.yaml"] = sha256(protocol_path)
    for archive in (args.data_dir / "BCICIV_2a_gdf.zip", args.data_dir / "true_labels.zip"):
        if archive.exists():
            metadata.setdefault("archive_sha256", {})[archive.name] = sha256(archive)
    (args.output_dir / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    result_rows: list[dict[str, Any]] = []
    eegnet_seed_rows: list[dict[str, Any]] = []
    manifest_rows: list[dict[str, Any]] = []
    selection_rows: list[dict[str, Any]] = []
    trial_manifest_rows: list[dict[str, Any]] = []
    prediction_rows: list[dict[str, Any]] = []
    aggregated_confusions = {
        model: np.zeros((4, 4), dtype=int)
        for model in ("FBCSP-SVM", "LE-TS-LR", EEGNET_MODEL_NAME)
    }

    for subject_index, subject in enumerate(args.subjects, start=1):
        print(f"Loading {subject}", flush=True)
        train_path = find_file(gdf_root, f"{subject}T.gdf")
        eval_path = find_file(gdf_root, f"{subject}E.gdf")
        label_path = find_file(label_root, f"{subject}E.mat")
        x_train_full, y_train_full, train_runs = load_session(train_path, "T")
        x_test, y_test, test_runs = load_session(eval_path, "E", load_evaluation_labels(label_path))
        assert_session_integrity(x_train_full, y_train_full, train_runs, subject, "T")
        assert_session_integrity(x_test, y_test, test_runs, subject, "E")
        manifest_rows.append(
            {
                "subject": subject,
                "train_trials": len(y_train_full),
                "test_trials": len(y_test),
                "channels": x_train_full.shape[1],
                "samples_per_epoch": x_train_full.shape[2],
                "train_class_counts": json.dumps(np.bincount(y_train_full, minlength=4).tolist()),
                "test_class_counts": json.dumps(np.bincount(y_test, minlength=4).tolist()),
                "train_run_counts": json.dumps(np.bincount(train_runs, minlength=7)[1:].tolist()),
                "test_run_counts": json.dumps(np.bincount(test_runs, minlength=7)[1:].tolist()),
            }
        )
        for session, labels, run_ids in (("T", y_train_full, train_runs), ("E", y_test, test_runs)):
            trial_manifest_rows.extend(
                {
                    "subject": subject,
                    "session": session,
                    "trial_index": int(index + 1),
                    "run": int(run_ids[index]),
                    "class_label": int(labels[index]),
                }
                for index in range(len(labels))
            )

        print(f"{subject}: selecting EEGNet epoch with leave-one-run-out validation in T", flush=True)
        selected_epoch, selection_table = select_eegnet_epoch_by_run(
            x_train_full, y_train_full, train_runs, subject_index, config
        )
        selection_table.insert(0, "subject", subject)
        selection_table["selected_final_epoch"] = selected_epoch
        selection_rows.extend(selection_table.to_dict(orient="records"))

        print(f"{subject}: FBCSP-SVM fit on all T-session trials", flush=True)
        fbcsp = FBCSPSVM(random_state=subject_index).fit(x_train_full, y_train_full)
        fbcsp_prediction = fbcsp.predict(x_test)
        fbcsp_metrics = model_metrics(y_test, fbcsp_prediction)
        result_rows.append({"subject": subject, "seed": "fixed", "model": "FBCSP-SVM", "best_epoch": np.nan, "validation_loss": np.nan, **fbcsp_metrics})
        prediction_rows.extend(make_trial_prediction_rows(subject, "FBCSP-SVM", "fixed", y_test, fbcsp_prediction, test_runs))
        aggregated_confusions["FBCSP-SVM"] += confusion_matrix(y_test, fbcsp_prediction, labels=range(4))

        print(f"{subject}: LE-TS-LR fit on all T-session trials", flush=True)
        letslr = LETSLR().fit(x_train_full, y_train_full)
        letslr_prediction = letslr.predict(x_test)
        letslr_metrics = model_metrics(y_test, letslr_prediction)
        result_rows.append({"subject": subject, "seed": "fixed", "model": "LE-TS-LR", "best_epoch": np.nan, "validation_loss": np.nan, **letslr_metrics})
        prediction_rows.extend(make_trial_prediction_rows(subject, "LE-TS-LR", "fixed", y_test, letslr_prediction, test_runs))
        aggregated_confusions["LE-TS-LR"] += confusion_matrix(y_test, letslr_prediction, labels=range(4))

        seed_probabilities: list[np.ndarray] = []
        for seed in config.seeds:
            run_seed = seed + subject_index * 10_000
            print(f"{subject}, seed {seed}: EEGNet full-T refit for {selected_epoch} epochs", flush=True)
            eegnet_prediction, eegnet_probabilities = train_eegnet_for_fixed_epochs(
                x_train_full, y_train_full, x_test, run_seed, selected_epoch, config
            )
            eegnet_metrics = model_metrics(y_test, eegnet_prediction)
            eegnet_seed_rows.append({"subject": subject, "seed": seed, "model": "EEGNet single refit", "best_epoch": selected_epoch, "validation_loss": selection_table["validation_loss"].median(), **eegnet_metrics})
            prediction_rows.extend(make_trial_prediction_rows(subject, "EEGNet single refit", seed, y_test, eegnet_prediction, test_runs))
            seed_probabilities.append(eegnet_probabilities)
            pd.DataFrame(result_rows + eegnet_seed_rows).to_csv(args.output_dir / "results_progress.csv", index=False)

        ensemble_probabilities = np.mean(np.stack(seed_probabilities, axis=0), axis=0)
        ensemble_prediction = ensemble_probabilities.argmax(axis=1).astype(np.int64)
        ensemble_metrics = model_metrics(y_test, ensemble_prediction)
        result_rows.append(
            {
                "subject": subject,
                "seed": "five_seed_probability_ensemble",
                "model": EEGNET_MODEL_NAME,
                "best_epoch": selected_epoch,
                "validation_loss": selection_table["validation_loss"].median(),
                **ensemble_metrics,
            }
        )
        prediction_rows.extend(
            make_trial_prediction_rows(
                subject,
                EEGNET_MODEL_NAME,
                "five_seed_probability_ensemble",
                y_test,
                ensemble_prediction,
                test_runs,
            )
        )
        aggregated_confusions[EEGNET_MODEL_NAME] += confusion_matrix(y_test, ensemble_prediction, labels=range(4))
        pd.DataFrame(result_rows + eegnet_seed_rows).to_csv(args.output_dir / "results_progress.csv", index=False)

    results = pd.DataFrame(result_rows)
    results.to_csv(args.output_dir / "model_level_results.csv", index=False)
    pd.DataFrame(eegnet_seed_rows).to_csv(args.output_dir / "eegnet_seed_level_results.csv", index=False)
    pd.DataFrame(manifest_rows).to_csv(args.output_dir / "dataset_manifest.csv", index=False)
    pd.DataFrame(trial_manifest_rows).to_csv(args.output_dir / "trial_manifest.csv", index=False)
    pd.DataFrame(prediction_rows).to_csv(args.output_dir / "trial_level_predictions.csv", index=False)
    pd.DataFrame(selection_rows).to_csv(args.output_dir / "eegnet_loro_selection.csv", index=False)
    subject_means = write_statistics(results, args.output_dir)
    write_summary(subject_means, args.output_dir)
    draw_subject_figure(subject_means, args.output_dir)
    draw_confusion_figures(aggregated_confusions, args.output_dir)
    print(f"Completed. Results written to {args.output_dir}", flush=True)


if __name__ == "__main__":
    main()
