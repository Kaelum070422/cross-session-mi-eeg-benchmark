"""Audit archived predictions and compute explicitly exploratory revision analyses.

Original result files are read only. No observed-effect/post-hoc power is computed.
Use --new-results CSV once the four supplementary classical variants are complete.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import rankdata, wilcoxon
from sklearn.metrics import accuracy_score, balanced_accuracy_score, cohen_kappa_score, f1_score

ENSEMBLE = "EEGNet (5-seed probability ensemble)"
SINGLE = "EEGNet single refit"
FIRST = "EEGNet first fixed seed"
SEEDMEAN = "EEGNet mean of five refit scores"
MODEL_ALIASES = {
    "EA + FBCSP-SVM tuned": "EA-FBCSP-SVM tuned",
    "EA + LE-TS-LR tuned": "EA-LE-TS-LR tuned",
}
SUBJECTS = [f"A{i:02d}" for i in range(1, 10)]
CLASSES = ["Left hand", "Right hand", "Feet", "Tongue"]
METRICS = ["accuracy", "balanced_accuracy", "macro_f1", "kappa"]
FAMILY = [
    (ENSEMBLE, SEEDMEAN),
    ("FBCSP-SVM tuned", "FBCSP-SVM"),
    ("LE-TS-LR tuned", "LE-TS-LR"),
    ("EA-FBCSP-SVM tuned", "FBCSP-SVM tuned"),
    ("EA-LE-TS-LR tuned", "LE-TS-LR tuned"),
    (SEEDMEAN, "FBCSP-SVM tuned"),
    (SEEDMEAN, "LE-TS-LR tuned"),
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sign_flip(delta: np.ndarray) -> float:
    signs = np.asarray(list(itertools.product((-1, 1), repeat=len(delta))))
    permuted = (signs @ delta) / len(delta)
    return float(np.mean(np.abs(permuted) >= abs(delta.mean()) - 1e-14))


def holm(values: list[float]) -> np.ndarray:
    values = np.asarray(values)
    order = np.argsort(values)
    adjusted = np.minimum(1, np.maximum.accumulate((len(values) - np.arange(len(values))) * values[order]))
    output = np.empty(len(values))
    output[order] = adjusted
    return output


def descriptive_ci(delta: np.ndarray, alpha: float = .05) -> tuple[float, float]:
    # Identical draw matrix across contrasts; intervals are percentile approximations.
    rng = np.random.default_rng(20260921)
    means = delta[rng.integers(0, len(delta), size=(200_000, len(delta)))].mean(axis=1)
    return tuple(float(x) for x in np.quantile(means, [alpha / 2, 1 - alpha / 2]))


def paired_rows(pivot: pd.DataFrame, contrasts, simultaneous_family_size=None):
    rows = []
    for left, right in contrasts:
        delta = (pivot[left] - pivot[right]).to_numpy()
        low, high = descriptive_ci(delta)
        w = wilcoxon(delta, alternative="two-sided", method="exact")
        row = dict(model_a=left, model_b=right, n_subjects=len(delta),
                   mean_difference_a_minus_b=delta.mean(), sd_difference=np.std(delta, ddof=1),
                   median_difference=np.median(delta), wins=int(sum(delta > 0)),
                   ties=int(sum(delta == 0)), losses=int(sum(delta < 0)),
                   bootstrap_descriptive_95ci_low=low, bootstrap_descriptive_95ci_high=high,
                   exact_sign_flip_p=sign_flip(delta), wilcoxon_statistic=float(w.statistic),
                   wilcoxon_p=float(w.pvalue))
        if simultaneous_family_size:
            low_b, high_b = descriptive_ci(delta, .05 / simultaneous_family_size)
            row.update(bootstrap_bonferroni_nominal_family95_low=low_b,
                       bootstrap_bonferroni_nominal_family95_high=high_b)
        rows.append(row)
    table = pd.DataFrame(rows)
    table["holm_sign_flip_p"] = holm(table.exact_sign_flip_p.tolist())
    table["holm_wilcoxon_p"] = holm(table.wilcoxon_p.tolist())
    return table


def power_sensitivity(draws=200_000):
    """Design-only minimum dz under iid Normal(dz,1) paired differences.

    Continuous samples have no zero differences/ties. Compute the exact signed-rank
    rejection region by enumerating all 512 signs, not a normal approximation.
    """
    ranks = np.arange(1, 10)
    sums = np.asarray([np.dot(s, ranks) for s in itertools.product((0, 1), repeat=9)])
    mass = np.bincount(sums, minlength=46) / 512
    cdf = np.cumsum(mass)
    rng = np.random.default_rng(271828)
    noise = rng.normal(size=(draws, 9))
    output = []
    for alpha in [.05, .05 / 3]:
        eligible = [w for w in range(23) if 2 * cdf[w] <= alpha + 1e-15]
        critical = max(eligible)

        def rejection(dz):
            shifted = noise + dz
            abs_ranks = rankdata(np.abs(shifted), axis=1)
            w_positive = (abs_ranks * (shifted > 0)).sum(axis=1)
            return float(np.mean(np.minimum(w_positive, 45 - w_positive) <= critical))

        low, high = 0., 3.
        for _ in range(16):
            middle = (low + high) / 2
            if rejection(middle) < .8:
                low = middle
            else:
                high = middle
        dz = (low + high) / 2
        achieved = rejection(dz)
        output.append(dict(n=9, alpha=alpha, target_power=.8, minimum_detectable_dz=dz,
                           estimated_power=achieved, monte_carlo_draws=draws,
                           monte_carlo_se_at_80pct=float(np.sqrt(.8 * .2 / draws)),
                           critical_min_signed_rank_sum=critical,
                           actual_null_size=float(2 * cdf[critical]),
                           minimum_attainable_two_sided_p=2 / 512,
                           random_seed=271828,
                           model="independent Normal(dz,1) participant paired differences; exact two-sided signed-rank test"))
    return pd.DataFrame(output)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--original-results", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--new-results", type=Path)
    p.add_argument("--new-predictions", type=Path)
    p.add_argument("--skip-power", action="store_true")
    args = p.parse_args()
    assert not args.new_predictions or args.new_results, "New predictions require corresponding metric rows"
    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    input_names = ["model_level_results.csv", "eegnet_seed_level_results.csv", "trial_level_predictions.csv", "primary_macro_f1_statistics.csv"]
    hashes = {name: sha256(args.original_results / name) for name in input_names}
    model = pd.read_csv(args.original_results / input_names[0])
    seed = pd.read_csv(args.original_results / input_names[1])
    pred = pd.read_csv(args.original_results / input_names[2])
    original_stat = pd.read_csv(args.original_results / input_names[3])
    assert len(model) == 27 and len(seed) == 45 and len(pred) == 20736
    assert set(model.subject) == set(SUBJECTS)
    assert not model.duplicated(["subject", "model"]).any()
    assert not seed.duplicated(["subject", "seed"]).any()
    assert set(seed.seed) == {20261, 20262, 20263, 20264, 20265}
    assert not pred.duplicated(["subject", "model", "seed", "trial_index"]).any()
    # Independently reproduce all 72 metric rows from the archived hard predictions.
    reproduced = []
    for (subject, name, value), group in pred.groupby(["subject", "model", "seed"]):
        group = group.sort_values("trial_index")
        assert len(group) == 288
        assert group.true_class.value_counts().to_dict() == {k: 72 for k in range(4)}
        truth = group.true_class.to_numpy()
        predicted = group.predicted_class.to_numpy()
        metrics = dict(accuracy=accuracy_score(truth, predicted),
                       balanced_accuracy=balanced_accuracy_score(truth, predicted),
                       macro_f1=f1_score(truth, predicted, average="macro", zero_division=0),
                       kappa=cohen_kappa_score(truth, predicted))
        reference = seed[(seed.subject == subject) & (seed.seed == int(value))] if name == SINGLE else model[(model.subject == subject) & (model.model == name)]
        assert len(reference) == 1
        errors = [abs(metrics[m] - float(reference.iloc[0][m])) for m in METRICS]
        assert max(errors) < 1e-12
        reproduced.append(dict(subject=subject, model=name, seed=value, max_abs_metric_error=max(errors)))
    pd.DataFrame(reproduced).to_csv(out / "archived_prediction_metric_recheck.csv", index=False)
    seedmean = seed.groupby("subject", as_index=False)[METRICS].mean().assign(model=SEEDMEAN)
    first = seed[seed.seed == 20261][["subject", *METRICS]].assign(model=FIRST)
    allmodels = pd.concat([model[["subject", "model", *METRICS]], seedmean, first], ignore_index=True)
    if args.new_results:
        extra = pd.read_csv(args.new_results)
        for column in ["subject", "model", *METRICS]:
            assert column in extra.columns
        extra["model"] = extra.model.replace(MODEL_ALIASES)
        expected_models = {"FBCSP-SVM tuned", "LE-TS-LR tuned", "EA-FBCSP-SVM tuned", "EA-LE-TS-LR tuned"}
        assert set(extra.model) == expected_models and len(extra) == 36
        assert not extra.duplicated(["subject", "model"]).any()
        assert all(set(group.subject) == set(SUBJECTS) for _, group in extra.groupby("model"))
        assert np.isfinite(extra[METRICS].to_numpy()).all()
        allmodels = pd.concat([allmodels, extra[["subject", "model", *METRICS]]], ignore_index=True)
        hashes[str(args.new_results)] = sha256(args.new_results)
    allmodels.to_csv(out / "all_subject_metrics.csv", index=False)
    summary = allmodels.groupby("model")[METRICS].agg(["mean", "std", "median", "min", "max"])
    summary.columns = ["_".join(x) for x in summary.columns]
    summary.reset_index().to_csv(out / "all_model_summary.csv", index=False)
    pivot = allmodels.pivot(index="subject", columns="model", values="macro_f1").reindex(SUBJECTS)
    seedwide = seed.pivot(index="subject", columns="seed", values="macro_f1").reindex(SUBJECTS)
    seedstats = pd.DataFrame(dict(subject=SUBJECTS, first_fixed_seed=seedwide[20261],
                                 mean_five_refits=seedwide.mean(axis=1),
                                 sd_five_refits=seedwide.std(axis=1, ddof=1),
                                 min_five_refits=seedwide.min(axis=1),
                                 max_five_refits=seedwide.max(axis=1),
                                 range_five_refits=seedwide.max(axis=1) - seedwide.min(axis=1),
                                 ensemble=pivot[ENSEMBLE]))
    seedstats["ensemble_minus_seedmean"] = seedstats.ensemble - seedstats.mean_five_refits
    seedstats["ensemble_minus_first"] = seedstats.ensemble - seedstats.first_fixed_seed
    seedstats["ensemble_minus_best_single_seed"] = seedstats.ensemble - seedstats.max_five_refits
    seedstats.to_csv(out / "eegnet_seed_stability.csv", index=False)
    original_contrasts = [(ENSEMBLE, "FBCSP-SVM"), (ENSEMBLE, "LE-TS-LR"), ("FBCSP-SVM", "LE-TS-LR")]
    original_recheck = paired_rows(pivot, original_contrasts, simultaneous_family_size=3)
    for _, old in original_stat.iterrows():
        matching = (original_recheck.model_a == old.model_a) & (original_recheck.model_b == old.model_b)
        new = original_recheck[matching].iloc[0]
        for oldkey, newkey in [("wilcoxon_p", "wilcoxon_p"), ("holm_adjusted_p", "holm_wilcoxon_p"), ("exact_sign_flip_p", "exact_sign_flip_p"), ("mean_difference_a_minus_b", "mean_difference_a_minus_b")]:
            assert abs(old[oldkey] - new[newkey]) < 1e-12
        original_recheck.loc[matching, "original_reported_bootstrap_95ci_low"] = old.bootstrap_95ci_low
        original_recheck.loc[matching, "original_reported_bootstrap_95ci_high"] = old.bootstrap_95ci_high
    original_recheck.to_csv(out / "original_three_contrasts_recheck.csv", index=False)
    deltas = []
    descriptive_contrasts = original_contrasts + [(ENSEMBLE, SEEDMEAN), (ENSEMBLE, FIRST), (SEEDMEAN, "FBCSP-SVM"), (SEEDMEAN, "LE-TS-LR")]
    if args.new_results:
        descriptive_contrasts.extend(pair for pair in FAMILY if pair not in descriptive_contrasts)
    for left, right in descriptive_contrasts:
        d = pivot[left] - pivot[right]
        for subject, value in d.items():
            deltas.append(dict(subject=subject, model_a=left, model_b=right, macro_f1_difference=value))
    pd.DataFrame(deltas).to_csv(out / "subject_model_differences.csv", index=False)
    # Only the original three models and the first fixed neural refit define actual decoders.
    selected = pred[(pred.model != SINGLE) | (pred.seed.astype(str) == "20261")].copy()
    selected.loc[selected.model == SINGLE, "model"] = FIRST
    additional_reproduced = []
    if args.new_predictions:
        new_pred = pd.read_csv(args.new_predictions)
        hashes[str(args.new_predictions)] = sha256(args.new_predictions)
        new_pred["model"] = new_pred.model.replace(MODEL_ALIASES)
        assert len(new_pred) == 10368
        assert not new_pred.duplicated(["subject", "model", "trial_index"]).any()
        assert set(new_pred.model) == expected_models
        for (subject, name), group in new_pred.groupby(["subject", "model"]):
            group = group.sort_values("trial_index")
            assert len(group) == 288 and set(group.trial_index) == set(range(1, 289))
            assert group.true_class.value_counts().to_dict() == {k: 72 for k in range(4)}
            original_truth = pred[(pred.subject == subject) & (pred.model == "FBCSP-SVM")].sort_values("trial_index").true_class.to_numpy()
            truth = group.true_class.to_numpy()
            assert np.array_equal(truth, original_truth)
            predicted = group.predicted_class.to_numpy()
            metrics = dict(accuracy=accuracy_score(truth, predicted),
                           balanced_accuracy=balanced_accuracy_score(truth, predicted),
                           macro_f1=f1_score(truth, predicted, average="macro", zero_division=0),
                           kappa=cohen_kappa_score(truth, predicted))
            reference = extra[(extra.subject == subject) & (extra.model == name)]
            assert len(reference) == 1
            max_error = max(abs(metrics[m] - float(reference.iloc[0][m])) for m in METRICS)
            assert max_error < 1e-12
            additional_reproduced.append(dict(subject=subject, model=name, max_abs_metric_error=max_error))
        pd.DataFrame(additional_reproduced).to_csv(out / "additional_prediction_metric_recheck.csv", index=False)
        selected = pd.concat([selected, new_pred], ignore_index=True)
    class_rows, error_rows = [], []
    for (subject, name), group in selected.groupby(["subject", "model"]):
        for k, class_name in enumerate(CLASSES):
            actual = group[group.true_class == k]
            class_rows.append(dict(subject=subject, model=name, class_index=k, class_name=class_name,
                                   n_true=len(actual), n_correct=int((actual.predicted_class == k).sum()),
                                   recall=float((actual.predicted_class == k).mean())))
            for j, predicted_name in enumerate(CLASSES):
                if k == j:
                    continue
                count = int((actual.predicted_class == j).sum())
                error_rows.append(dict(subject=subject, model=name, true_class=class_name,
                                       predicted_class=predicted_name, count=count, rate_given_true=count / len(actual)))
    class_table = pd.DataFrame(class_rows)
    class_table.to_csv(out / "subject_class_recalls.csv", index=False)
    class_summary = class_table.groupby(["model", "class_name"]).agg(mean_recall=("recall", "mean"), sd_across_subjects=("recall", "std"), min_recall=("recall", "min"), max_recall=("recall", "max"), total_correct=("n_correct", "sum"), total_true=("n_true", "sum")).reset_index()
    class_summary.to_csv(out / "model_class_recall_summary.csv", index=False)
    errors = pd.DataFrame(error_rows)
    errors.to_csv(out / "subject_error_directions.csv", index=False)
    errors.groupby(["model", "true_class", "predicted_class"], as_index=False).agg(count=("count", "sum"), mean_rate_given_true=("rate_given_true", "mean")).sort_values(["model", "count"], ascending=[True, False]).to_csv(out / "aggregate_error_directions.csv", index=False)
    family_schema = pd.DataFrame([dict(contrast=i + 1, model_a=a, model_b=b) for i, (a, b) in enumerate(FAMILY)])
    family_schema.to_csv(out / "frozen_exploratory_family.csv", index=False)
    if args.new_results:
        for name in set(x for pair in FAMILY for x in pair):
            assert name in pivot.columns and pivot[name].notna().all()
        paired_rows(pivot, FAMILY).to_csv(out / "exploratory_seven_contrasts.csv", index=False)
    if not args.skip_power:
        power_sensitivity().to_csv(out / "design_sensitivity_normal_location.csv", index=False)
    meta = dict(original_results=str(args.original_results), inputs_sha256=hashes,
                source_script_sha256=sha256(Path(__file__)), n_subjects=9,
                metric_rows_reproduced=len(reproduced), metric_recheck_tolerance=1e-12,
                additional_metric_rows_reproduced=len(additional_reproduced),
                first_seed_rule="First listed base seed 20261, actual RNG seed 20261 + participant_index * 10000, index begins 1; chosen by fixed order, not E performance. This reporting rule was adopted after original E results were known.",
                seedmean_rule="Per-subject arithmetic mean of five single-refit metrics; descriptive stochastic-training summary, not a deployed predictor or averaged probability ensemble.",
                exploratory_family_rule="Seven frozen contrasts, exact two-sided sign-flip mean-difference p values, Holm across seven. All revision inference is exploratory because original E scores were known.",
                bootstrap_rule="200000 resamples of paired participant rows across the nine participants, seed 20260921; marginal 95% percentile intervals descriptive and not simultaneous; nominal Bonferroni percentile intervals for original three are approximate sensitivity only, not exact coverage. Original reported intervals retained separately from revision recomputation.",
                additional_model_name_mapping=MODEL_ALIASES,
                signflip_assumption="Independent participant difference signs exchangeable under null (e.g. symmetric zero-centered differences); not exact under an arbitrary mean-zero skew distribution.",
                power_rule="Design sensitivity under assumed independent Normal(dz,1) differences; 200000 simulations; exact signed-rank rejection regions; NOT observed-effect posthoc power; not an assertion about unknown BCI population effects.")
    (out / "analysis_metadata.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    assert hashes == {name: sha256(args.original_results / name) if name in input_names else sha256(Path(name)) for name in hashes}
    print(summary.to_string())
    print("\nSeed audit:\n", seedstats.to_string(index=False))
    print("\nOriginal comparisons rechecked:\n", original_recheck.to_string(index=False))
    print("\nAll original input hashes unchanged. Outputs:", out)


if __name__ == "__main__":
    main()
