# Verified statistical findings for the revision

This is an internal analysis note, not a claim of independent confirmatory validation. The original E-session results were already known when the revision was designed. The seven supplementary contrasts use a fixed family, participant-level exact two-sided sign-flip tests of the mean difference, and Holm correction across all seven. Participant count is nine; neither trials nor seeds are treated as independent participants. Positive differences favor the first named condition.

## Group results

| Condition | Accuracy | Macro-F1, mean ± between-participant SD | Kappa |
|---|---:|---:|---:|
| Fixed FBCSP-SVM | .589892 | .578625 ± .167933 | .453189 |
| Source-tuned FBCSP-SVM | .627701 | .618682 ± .176793 | .503601 |
| EA + tuned FBCSP-SVM | .670139 | .668582 ± .167502 | .560185 |
| Fixed LE-TS-LR | .584877 | .579243 ± .181318 | .446502 |
| Source-tuned LE-TS-LR | .607639 | .602257 ± .170622 | .476852 |
| EA + tuned LE-TS-LR | .645833 | .645575 ± .178134 | .527778 |
| Neural base seed 20261 | .632330 | .611815 ± .180085 | .509774 |
| Mean of five neural single-refit scores | .628086 | .612025 ± .181353 | .504115 |
| Five-seed neural probability ensemble | .653164 | .637478 ± .173790 | .537551 |

EA uses unlabeled E-session signals, so its results belong to a separate transductive condition, not the source-only comparison. The mean of single-refit scores is a descriptive training-seed summary, not a deployed classifier. Base seed 20261 is the first listed seed; using it as a representative run is a revision reporting rule, not an original preregistration. Actual RNG seed is 20261 + subject index × 10000, with subject index 1–9.

## Frozen seven-contrast exploratory family

| Difference | Mean Δ macro-F1 | Marginal descriptive 95% bootstrap CI | Exact sign-flip p | Holm p | Wins / ties / losses |
|---|---:|---:|---:|---:|---:|
| Ensemble − mean single-refit score | +.025453 | [.011734, .040478] | .015625 | .062500 | 7 / 0 / 2 |
| Tuned FBCSP − fixed FBCSP | +.040058 | [.023624, .057371] | .007813 | .046875 | 8 / 1 / 0 |
| Tuned LE − fixed LE | +.023014 | [.012406, .032595] | .011719 | .058594 | 8 / 0 / 1 |
| EA tuned FBCSP − tuned FBCSP | +.049899 | [−.000426, .103655] | .148438 | .445313 | 5 / 0 / 4 |
| EA tuned LE − tuned LE | +.043318 | [.025222, .065969] | .003906 | .027344 | 9 / 0 / 0 |
| Mean single-refit score − tuned FBCSP | −.006658 | [−.065639, .046969] | .843750 | 1.000000 | 5 / 0 / 4 |
| Mean single-refit score − tuned LE | +.009768 | [−.025905, .043216] | .609375 | 1.000000 | 5 / 0 / 4 |

Do not claim neural architecture superiority. Under the revised exploratory decision rule, only FBCSP tuning and the EA-LE pipeline contrast have adjusted p < .05. The EA contrasts compare separately retuned pipelines; they do not isolate a whitening-only effect at fixed C. Nonsignificance does not establish equivalence. The sign-flip test is exact under exchangeable independent difference signs (for example a symmetric zero-centered distribution), not under every arbitrary mean-zero distribution.

## Original inference and the bootstrap question

Original three-comparison signed-rank results were reproduced: neural ensemble minus FBCSP p=.0546875, Holm=.1640625; ensemble minus LE p=.12890625, Holm=.2578125; FBCSP minus LE p=1, Holm=1. The original reported percentile CIs are separately retained in `original_three_contrasts_recheck.csv`: [.004155, .107300] and [.010536, .105772] for the two neural contrasts. The revision's 200,000-resample estimates are close but not numerically identical and must not replace the original endpoints without labeling the recomputation.

These marginal percentile intervals describe mean differences, are approximate in this small sample, and are not simultaneous intervals. They are neither inversions of the exact signed-rank test (which uses ranks and a symmetry/location null) nor inversions of the exact sign-flip test (which uses the mean statistic but a different reference distribution). Their exclusion of zero therefore does not override the declared multiplicity-adjusted test. The sign-flip p values for the original neural contrasts are .058594 and .078125 even before correction. Do not portray the discrepancy as numerical inconsistency or select whichever procedure gives significance.

Design sensitivity: under independent Normal(d_z, 1) paired participant differences and an exact two-sided signed-rank test, 200,000 simulations gave approximately 80% power at d_z=1.149 for alpha=.05, and d_z=1.477 at alpha=.05/3. The latter is a conservative Bonferroni threshold for the original family, not an exact Holm power calculation and not the seven-contrast family threshold. Monte Carlo SE at .8 power is .000894. This is assumption-based design sensitivity, not observed post-hoc power. With n=9 the minimum attainable two-sided signed-rank p is 2/512=.00390625: significance is possible, not structurally impossible.

## Participant and class heterogeneity

- A02: ensemble macro-F1 .301617 versus fixed FBCSP .416507 and tuned FBCSP .469858. Neural recalls are left .763889, right .111111, feet .486111, tongue .055556. This identifies class-specific failure, not uniformly poor decoding; its physiological or recording cause has not been established.
- A05: ensemble .508787 versus fixed FBCSP .380707 and fixed LE .365819. Its tongue recall is .583333 versus FBCSP .041667, but neural feet recall is worse (.152778 versus .291667). The aggregate improvement is not an across-class improvement.
- A06: ensemble .519576 versus fixed FBCSP .364098 and fixed LE .380733. Neural recall exceeds both fixed baselines in all four classes, contrasting with A05's trade-off.
- A07: fixed FBCSP .696810 exceeds fixed LE .597507. FBCSP has higher right-hand/feet recall (.930556/.847222 versus .416667/.472222), but lower tongue recall (.402778 versus .833333).
- A09: fixed LE .773306 exceeds fixed FBCSP .646056, particularly on tongue (.930556 versus .333333), despite lower right-hand recall (.541667 versus .763889). Together A07/A09 show model-by-participant/class interaction. Do not select a participant-specific decoder retrospectively using these E labels.
- EA-FBCSP improves mean performance but worsens four participants (A02, A06, A07, A08); its largest decrease is A07 (−.056963). EA-LE improves macro-F1 for all nine, largest A07 (+.119358). Neither finding explains physiological mechanisms.
- Across original fixed FBCSP / fixed LE / ensemble, tongue recall is .441358 / .634259 / .655864; feet recall is .581790 / .489198 / .512346. Feet→tongue errors are .169753 / .233025 / .239198, whereas tongue→feet errors are .209877 / .126543 / .091049. The confusions are directional, not symmetric. FBCSP's largest tongue error is to right hand (.214506), marginally above tongue→feet. LE's largest pooled off-diagonal error is right→left (.282407).
- Tuning increases FBCSP tongue recall to .524691, and the separately tuned EA-FBCSP pipeline reaches .671296. LE feet recall increases from .489198 to .537037 with tuning and .628086 with EA; its tongue recall is .634259 / .646605 / .635802, so alignment is not uniformly beneficial by class.
- Within-participant single-refit variability is largest for A07 (SD .075637, range .185448) and A02 (SD .064644, range .155766). Ensemble exceeds the within-participant seed mean in 7/9, but exceeds the best observed seed in only 2/9; selecting that best E-scoring seed would be test-set selection and is not an allowed baseline.

## Audit and reproduction

All 72 original participant/model-or-seed metric rows and all 36 supplemental participant/model rows were independently reproduced from archived hard predictions, with maximum absolute tolerance 1e−12. Supplemental true-label vectors were checked against the original trial order. All nine participants have 72 trials per class, so accuracy equals balanced accuracy algebraically; only one needs to appear in the main table. Original input hashes were unchanged.

Run from the paper workspace with the existing scientific environment:

```text
python revision_20260921/analysis/analyze_revision.py --original-results reproducibility/results_final_ensemble --output-dir revision_20260921/analysis --new-results revision_20260921/experiments/results/model_level_results.csv --new-predictions revision_20260921/experiments/results/trial_level_predictions.csv
```

Add `--skip-power` only when retaining the existing design-sensitivity CSV. Raw results and predictions are never modified by the analysis script.
