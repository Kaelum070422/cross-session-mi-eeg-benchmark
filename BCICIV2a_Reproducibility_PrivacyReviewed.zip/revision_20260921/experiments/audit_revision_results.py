"""Independent post-run checks for the reviewer-requested baseline experiment."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, balanced_accuracy_score, cohen_kappa_score, f1_score


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUT = HERE / "results"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    metadata = json.loads((OUT / "run_metadata.json").read_text(encoding="utf-8"))
    lock = json.loads((OUT / "prediction_lock.json").read_text(encoding="utf-8"))
    assert metadata["status"] == "complete"
    assert metadata["start_utc"] < lock["predictions_locked_utc"] < metadata["end_utc"]
    frozen = metadata["script_hashes"]
    assert frozen["revision_script"] == digest(HERE / "run_revision_baselines.py")
    assert frozen["revision_protocol"] == digest(HERE / "protocol.json")
    assert frozen["base_script"] == digest(ROOT / "reproducibility/run_cross_session_benchmark.py")
    assert lock["predictions_before_E_labels_sha256"] == digest(OUT / "predictions_before_E_labels.csv")
    assert lock["selection_settings_sha256"] == digest(OUT / "selection_settings.csv")
    pre = pd.read_csv(OUT / "predictions_before_E_labels.csv")
    pred = pd.read_csv(OUT / "trial_level_predictions.csv")
    metrics = pd.read_csv(OUT / "model_level_results.csv")
    selected = pd.read_csv(OUT / "selection_settings.csv")
    scores = pd.read_csv(OUT / "fold_C_scores.csv")
    folds = pd.read_csv(OUT / "source_fold_manifest.csv")
    pd.testing.assert_frame_equal(pre, pred[pre.columns], check_dtype=False)
    assert len(pred) == 9 * 4 * 288
    assert len(metrics) == len(selected) == 9 * 4
    assert len(scores) == 9 * 4 * 6 * 5
    assert len(folds) == 9 * 6
    assert set(pred.subject) == {f"A{i:02d}" for i in range(1, 10)}
    for row in folds.itertuples():
        tr = {int(i) for i in row.train_indices_zero_based.split()}
        va = {int(i) for i in row.validation_indices_zero_based.split()}
        assert len(tr) == 240 and len(va) == 48 and tr.isdisjoint(va)
        assert tr | va == set(range(288))
        assert {int(i) for i in row.train_runs.split()} == set(range(1, 7)) - {row.heldout_run}
    for row in selected.itertuples():
        part = scores[(scores.subject == row.subject) & (scores.model == row.model)]
        assert set(part.C) == {.01, .1, 1., 10., 100.}
        assert all(part.groupby("C").heldout_run.nunique() == 6)
        means = part.groupby("C").macro_f1.mean()
        expected = min(means[means.max() - means <= 1e-12].index)
        assert expected == row.selected_C
        assert abs(means[expected] - row.selected_mean_validation_macro_f1) < 1e-12
    for row in metrics.itertuples():
        part = pred[(pred.subject == row.subject) & (pred.model == row.model)].sort_values("trial_index")
        assert list(part.trial_index) == list(range(1, 289))
        assert part.true_class.value_counts().to_dict() == {0: 72, 1: 72, 2: 72, 3: 72}
        assert part.evaluation_run.value_counts().to_dict() == {i: 48 for i in range(1, 7)}
        actual = {
            "accuracy": accuracy_score(part.true_class, part.predicted_class),
            "balanced_accuracy": balanced_accuracy_score(part.true_class, part.predicted_class),
            "macro_f1": f1_score(part.true_class, part.predicted_class, average="macro"),
            "kappa": cohen_kappa_score(part.true_class, part.predicted_class),
        }
        for name, value in actual.items():
            assert abs(value - getattr(row, name)) < 1e-12
        assert abs(actual["accuracy"] - actual["balanced_accuracy"]) < 1e-12
    ea_errors = []
    state_files = sorted(OUT.glob("*_EA.npz"))
    assert len(state_files) == 9 * 7
    for path in state_files:
        with np.load(path) as saved:
            for domain in ("source", "target"):
                reference = saved[domain + "_reference"]
                whitener = saved[domain + "_whitener"]
                assert reference.shape == whitener.shape == (22, 22)
                assert np.linalg.eigvalsh(reference).min() > 0
                err = float(np.max(np.abs(whitener @ reference @ whitener.T - np.eye(22))))
                assert err < 1e-7
                ea_errors.append({"file": path.name, "domain": domain, "identity_max_abs_error": err})
    pd.DataFrame(ea_errors).to_csv(OUT / "ea_whitening_validation.csv", index=False)
    # Where source validation selected C=1, the untuned original must be reproduced.
    original_path = ROOT / "reproducibility/results_final_ensemble/trial_level_predictions.csv"
    parity = []
    original = pd.read_csv(original_path)
    for subject in sorted(pred.subject.unique()):
        old_trials = original[(original.subject == subject) & (original.model == "FBCSP-SVM")].sort_values("trial_index")
        assert len(old_trials) == 288
        for _, new_trials in pred[pred.subject == subject].groupby("model"):
            new_trials = new_trials.sort_values("trial_index")
            assert np.array_equal(old_trials.true_class.to_numpy(), new_trials.true_class.to_numpy())
            assert np.array_equal(old_trials.evaluation_run.to_numpy(), new_trials.evaluation_run.to_numpy())
    for row in selected.itertuples():
        if row.model.startswith("EA") or row.selected_C != 1:
            continue
        name = row.model.removesuffix(" tuned")
        old = original[(original.subject == row.subject) & (original.model == name)]
        new = pred[(pred.subject == row.subject) & (pred.model == row.model)]
        old = old.sort_values("trial_index")
        new = new.sort_values("trial_index")
        assert len(old) == len(new) == 288
        assert np.array_equal(old.predicted_class.to_numpy(), new.predicted_class.to_numpy())
        parity.append({"subject": row.subject, "model": name, "predictions_equal": True})
    result = {
        "status": "passed",
        "nine_subjects_four_arms": True,
        "metric_rows": len(metrics),
        "prediction_rows": len(pred),
        "source_fold_C_score_rows": len(scores),
        "source_folds_disjoint": True,
        "all_selected_C_match_source_fold_scores": True,
        "predictions_unchanged_after_E_label_load": True,
        "metrics_independently_recomputed": True,
        "target_label_and_run_order_match_original": True,
        "frozen_scripts_unchanged": True,
        "ea_state_files": len(state_files),
        "ea_whitening_max_absolute_error": max(r["identity_max_abs_error"] for r in ea_errors),
        "fixed_C1_original_prediction_parity": parity,
        "caveat": "This audit verifies persisted artifacts and code invariants, not prospective preregistration; revision outcomes remain exploratory.",
    }
    (OUT / "validation_report.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
