"""Source-only C selection and explicitly transductive EA revision experiments.

The original benchmark is imported as a read-only implementation reference.
No evaluation labels are loaded until all requested subjects have completed
source-only selection, final training, and prediction. Run --self-test first.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import sys
import time
from datetime import datetime, timezone
from functools import partial

import numpy as np
import pandas as pd
from scipy import signal
from sklearn.feature_selection import SelectKBest, mutual_info_classif
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from threadpoolctl import threadpool_limits


SCRIPT = Path(__file__).resolve()
PROTOCOL = SCRIPT.with_name("protocol.json")
DEFAULT_BASE = SCRIPT.parents[2] / "reproducibility" / "run_cross_session_benchmark.py"
GRID = (0.01, 0.1, 1.0, 10.0, 100.0)
ARMS = ((False, "FBCSP"), (False, "LE"), (True, "FBCSP"), (True, "LE"))
NAMES = {
    (False, "FBCSP"): "FBCSP-SVM tuned",
    (False, "LE"): "LE-TS-LR tuned",
    (True, "FBCSP"): "EA + FBCSP-SVM tuned",
    (True, "LE"): "EA + LE-TS-LR tuned",
}


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def utcnow():
    return datetime.now(timezone.utc).isoformat()


def save_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def load_base(path):
    spec = importlib.util.spec_from_file_location("original_benchmark", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def arithmetic_covariance(x):
    centered = np.asarray(x, dtype=np.float64) - np.mean(x, axis=-1, keepdims=True, dtype=np.float64)
    return np.einsum("nct,ndt->cd", centered, centered, optimize=True) / (len(x) * (x.shape[-1] - 1))


def fit_ea(x):
    reference = arithmetic_covariance(x)
    values, vectors = np.linalg.eigh(reference)
    floor = max(float(values[-1]) * 1e-12, 1e-12)
    whitener = (vectors * np.maximum(values, floor) ** -0.5) @ vectors.T
    return reference, whitener


def apply_ea(x, whitener):
    return np.einsum("cd,ndt->nct", whitener, x, optimize=True)


def prepare_domains(x_train, x_target, ea):
    if not ea:
        return x_train, x_target, {}
    source_reference, source_whitener = fit_ea(x_train)
    target_reference, target_whitener = fit_ea(x_target)
    return apply_ea(x_train, source_whitener), apply_ea(x_target, target_whitener), {
        "source_reference": source_reference,
        "source_whitener": source_whitener,
        "target_reference": target_reference,
        "target_whitener": target_whitener,
    }


class FeatureTransformer:
    def __init__(self, base, family, seed):
        self.base, self.family, self.seed = base, family, seed

    def fit_transform(self, x, y):
        if self.family == "FBCSP":
            self.extractor = self.base.FBCSPSVM(random_state=self.seed)
            for low, high in self.extractor.bands:
                sos = signal.butter(4, [low, high], btype="bandpass", fs=self.base.FS, output="sos")
                band_data = self.extractor._bandpass(x, sos)
                self.extractor.sos_filters.append(sos)
                self.extractor.csp_filters.append([
                    self.extractor._fit_csp(band_data, y, target) for target in range(4)
                ])
            raw = self.extractor._features(x)
            self.selector = SelectKBest(partial(mutual_info_classif, random_state=self.seed), k=min(20, raw.shape[1]))
            raw = self.selector.fit_transform(raw, y)
        else:
            self.extractor = self.base.LETSLR()
            covariances = self.extractor._covariances(x)
            self.extractor.log_reference = np.mean(
                np.stack([self.base._matrix_log_spd(c) for c in covariances]), axis=0)
            raw = self.extractor._tangent_features(covariances)
        self.scaler = StandardScaler().fit(raw)
        return self.scaler.transform(raw)

    def transform(self, x):
        if self.family == "FBCSP":
            raw = self.selector.transform(self.extractor._features(x))
        else:
            raw = self.extractor._tangent_features(self.extractor._covariances(x))
        return self.scaler.transform(raw)


def classifier(family, c):
    if family == "FBCSP":
        return SVC(kernel="linear", C=c, decision_function_shape="ovr")
    return LogisticRegression(C=c, solver="lbfgs", max_iter=5000, random_state=0)


def select_c(scores):
    means = {c: float(np.mean(scores[c])) for c in GRID}
    best = max(means.values())
    selected = min(c for c in GRID if best - means[c] <= 1e-12)
    return selected, means


def load_unlabeled_e(base, gdf_path):
    # Deliberately independent of base.load_session: no label argument or read.
    mne = base.mne
    raw = mne.io.read_raw_gdf(gdf_path, preload=True, verbose="ERROR")
    if len(raw.ch_names) < 25:
        raise ValueError("Unexpected channel count")
    raw.pick(raw.ch_names[:22])
    raw.filter(4.0, 38.0, method="fir", phase="zero", verbose="ERROR")
    events, event_id = mne.events_from_annotations(raw, verbose="ERROR")
    code = base._event_code(event_id, 783)
    epochs = mne.Epochs(raw, events, event_id={"783": code}, tmin=base.EPOCH_TMIN,
                       tmax=base.EPOCH_TMAX, baseline=None, preload=True,
                       reject_by_annotation=False, verbose="ERROR")
    x = (epochs.get_data(copy=True) * 1e6).astype(np.float32)
    runs = base._run_ids(events, event_id, epochs.events)
    assert x.shape == (288, 22, 501)
    assert np.array_equal(np.bincount(runs, minlength=7)[1:], np.full(6, 48))
    assert np.isfinite(x).all()
    return x, runs


def self_test(base, output):
    rng = np.random.default_rng(20260921)
    mix = rng.normal(size=(6, 6)) + 3 * np.eye(6)
    x = np.einsum("cd,ndt->nct", mix, rng.normal(size=(72, 6, 100)))
    y = np.tile(np.arange(4), 18)
    runs = np.repeat(np.arange(1, 7), 12)
    reference, white = fit_ea(x)
    identity_error = float(np.max(np.abs(arithmetic_covariance(apply_ea(x, white)) - np.eye(6))))
    assert identity_error < 1e-10
    assert np.allclose(reference, np.mean([np.cov(epoch) for epoch in x], axis=0))
    # Changing target data must not change any source-domain alignment state.
    tx1, vx1, state1 = prepare_domains(x[runs != 1], x[runs == 1], True)
    tx2, vx2, state2 = prepare_domains(x[runs != 1], x[runs == 1] * 7, True)
    assert np.array_equal(state1["source_reference"], state2["source_reference"])
    assert np.array_equal(tx1, tx2)
    for heldout in range(1, 7):
        tr, va = np.flatnonzero(runs != heldout), np.flatnonzero(runs == heldout)
        assert not np.intersect1d(tr, va).size and len(tr) + len(va) == len(x)
        assert set(runs[tr]) == set(range(1, 7)) - {heldout}
    # New refactored feature pipeline must match original fixed-C classifiers.
    parity = {}
    for family in ("FBCSP", "LE"):
        tr, va = runs != 1, runs == 1
        ft = FeatureTransformer(base, family, 1)
        features = ft.fit_transform(x[tr], y[tr])
        selected = ft.transform(x[va])
        fitted = classifier(family, 1).fit(features, y[tr])
        pred = fitted.predict(selected)
        original = base.FBCSPSVM(random_state=1) if family == "FBCSP" else base.LETSLR()
        expected = original.fit(x[tr], y[tr]).predict(x[va])
        assert np.array_equal(pred, expected)
        before = ft.scaler.mean_.copy()
        ft.transform(x[va] * 8)
        assert np.array_equal(before, ft.scaler.mean_)
        parity[family] = True
    equal_scores = {c: [0.5] * 6 for c in GRID}
    assert select_c(equal_scores)[0] == min(GRID)
    result = {"status": "passed", "timestamp_utc": utcnow(), "ea_identity_max_absolute_error": identity_error,
              "ea_equals_mean_np_cov": True, "source_ref_invariant_to_target_perturbation": True,
              "run_disjointness": True, "original_fixed_C_prediction_parity": parity,
              "target_transform_does_not_mutate_train_scaler": True, "tie_break_smallest_C": True}
    save_json(output, result)
    print(json.dumps(result, indent=2), flush=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--base-script", type=Path, default=DEFAULT_BASE)
    ap.add_argument("--data-dir", type=Path)
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--subjects", nargs="+", default=[f"A{i:02d}" for i in range(1, 10)])
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    base = load_base(args.base_script)
    base.torch.set_num_threads(args.threads)
    with threadpool_limits(limits=args.threads):
        if args.self_test:
            self_test(base, args.output_dir / "self_test.json")
            return
        if args.data_dir is None:
            ap.error("--data-dir is required for the experiment")
        if (args.output_dir / "run_metadata.json").exists():
            raise FileExistsError("Refusing to overwrite an existing experiment output")
        frozen = {"revision_script": sha256(SCRIPT), "revision_protocol": sha256(PROTOCOL),
                  "base_script": sha256(args.base_script)}
        metadata = {"status": "running", "start_utc": utcnow(), "subjects": args.subjects,
                    "script_hashes": frozen, "command": sys.argv, "C_grid": GRID,
                    "python": sys.version, "platform": platform.platform(), "threads": args.threads,
                    "packages": {"numpy": np.__version__, "pandas": pd.__version__, "scipy": base.scipy.__version__,
                                 "sklearn": base.sklearn.__version__, "mne": base.mne.__version__},
                    "protocol": json.loads(PROTOCOL.read_text(encoding="utf-8")),
                    "E_labels_loaded": False}
        save_json(args.output_dir / "run_metadata.json", metadata)
        selections, fold_scores, audit, predictions, manifests = [], [], [], [], []
        t0 = time.perf_counter()
        for subject in args.subjects:
            subject_start = time.perf_counter()
            sid = int(subject[1:])
            print(f"{utcnow()} {subject}: loading source and unlabeled target", flush=True)
            tfile = base.find_file(args.data_dir, subject + "T.gdf")
            efile = base.find_file(args.data_dir, subject + "E.gdf")
            x, y, runs = base.load_session(tfile, "T")
            base.assert_session_integrity(x, y, runs, subject, "T")
            xt, target_runs = load_unlabeled_e(base, efile)
            manifests.append({"subject": subject, "T_gdf_sha256": sha256(tfile), "E_gdf_sha256": sha256(efile),
                              "T_trials": len(x), "E_trials": len(xt), "channels": x.shape[1], "samples": x.shape[2]})
            scores = {arm: {c: [] for c in GRID} for arm in ARMS}
            for heldout in range(1, 7):
                tr, va = np.flatnonzero(runs != heldout), np.flatnonzero(runs == heldout)
                assert len(tr) == 240 and len(va) == 48 and not np.intersect1d(tr, va).size
                audit.append({"subject": subject, "heldout_run": heldout,
                              "train_indices_zero_based": " ".join(map(str, tr)),
                              "validation_indices_zero_based": " ".join(map(str, va)),
                              "train_n": len(tr), "validation_n": len(va),
                              "train_runs": " ".join(map(str, sorted(set(runs[tr]))))})
                for ea in (False, True):
                    train_data, val_data, states = prepare_domains(x[tr], x[va], ea)
                    if ea:
                        np.savez_compressed(args.output_dir / f"{subject}_fold{heldout}_EA.npz", **states)
                    for family in ("FBCSP", "LE"):
                        features = FeatureTransformer(base, family, sid)
                        train_features = features.fit_transform(train_data, y[tr])
                        val_features = features.transform(val_data)
                        for c in GRID:
                            fitted = classifier(family, c).fit(train_features, y[tr])
                            predicted = fitted.predict(val_features)
                            score = float(f1_score(y[va], predicted, average="macro", labels=np.arange(4), zero_division=0))
                            scores[(ea, family)][c].append(score)
                            fold_scores.append({"subject": subject, "model": NAMES[(ea, family)],
                                                "heldout_run": heldout, "C": c, "macro_f1": score})
                print(f"{utcnow()} {subject}: source fold {heldout}/6 complete", flush=True)
            for ea in (False, True):
                train_data, target_data, states = prepare_domains(x, xt, ea)
                if ea:
                    np.savez_compressed(args.output_dir / f"{subject}_final_EA.npz", **states)
                for family in ("FBCSP", "LE"):
                    c, means = select_c(scores[(ea, family)])
                    features = FeatureTransformer(base, family, sid)
                    train_features = features.fit_transform(train_data, y)
                    target_features = features.transform(target_data)
                    fitted = classifier(family, c).fit(train_features, y)
                    predicted = fitted.predict(target_features)
                    armname = NAMES[(ea, family)]
                    row = {"subject": subject, "model": armname, "selected_C": c,
                           "selected_mean_validation_macro_f1": means[c],
                           "protocol": "transductive_EA" if ea else "inductive"}
                    row.update({f"mean_validation_C_{value:g}": means[value] for value in GRID})
                    selections.append(row)
                    predictions.extend({"subject": subject, "model": armname, "trial_index": i + 1,
                                        "evaluation_run": int(target_runs[i]), "predicted_class": int(predicted[i])}
                                       for i in range(len(predicted)))
            pd.DataFrame(selections).to_csv(args.output_dir / "selection_settings.csv", index=False)
            pd.DataFrame(fold_scores).to_csv(args.output_dir / "fold_C_scores.csv", index=False)
            pd.DataFrame(audit).to_csv(args.output_dir / "source_fold_manifest.csv", index=False)
            pd.DataFrame(predictions).to_csv(args.output_dir / "predictions_before_E_labels.csv", index=False)
            pd.DataFrame(manifests).to_csv(args.output_dir / "dataset_manifest.csv", index=False)
            print(f"{utcnow()} {subject}: predictions locked after {time.perf_counter() - subject_start:.1f}s; E labels not loaded", flush=True)
        # Label boundary: all tuning and all predictions above are complete.
        assert frozen == {"revision_script": sha256(SCRIPT), "revision_protocol": sha256(PROTOCOL),
                          "base_script": sha256(args.base_script)}, "Analysis code changed mid-run"
        metadata["predictions_locked_utc"] = utcnow()
        metadata["predictions_before_E_labels_sha256"] = sha256(args.output_dir / "predictions_before_E_labels.csv")
        metadata["selection_settings_sha256"] = sha256(args.output_dir / "selection_settings.csv")
        save_json(args.output_dir / "prediction_lock.json", {k: metadata[k] for k in (
            "predictions_locked_utc", "predictions_before_E_labels_sha256", "selection_settings_sha256", "script_hashes")})
        print(f"{utcnow()} All predictions locked. Loading evaluation labels for scoring only.", flush=True)
        predframe = pd.DataFrame(predictions)
        results, scored_predictions = [], []
        for subject in args.subjects:
            labelfile = base.find_file(args.data_dir, subject + "E.mat")
            target_y = base.load_evaluation_labels(labelfile)
            assert np.array_equal(np.bincount(target_y, minlength=4), np.full(4, 72))
            for ea, family in ARMS:
                name = NAMES[(ea, family)]
                part = predframe[(predframe.subject == subject) & (predframe.model == name)].sort_values("trial_index").copy()
                assert len(part) == 288
                part["true_class"] = target_y
                scored_predictions.append(part)
                chosen = next(row for row in selections if row["subject"] == subject and row["model"] == name)
                results.append({"subject": subject, "model": name,
                                "protocol": chosen["protocol"], "selected_C": chosen["selected_C"],
                                **base.model_metrics(target_y, part.predicted_class.to_numpy())})
            manifests[args.subjects.index(subject)]["E_labels_sha256"] = sha256(labelfile)
        resultframe = pd.DataFrame(results)
        resultframe.to_csv(args.output_dir / "model_level_results.csv", index=False)
        pd.concat(scored_predictions, ignore_index=True).to_csv(args.output_dir / "trial_level_predictions.csv", index=False)
        pd.DataFrame(manifests).to_csv(args.output_dir / "dataset_manifest.csv", index=False)
        summary = resultframe.groupby(["protocol", "model"])[["accuracy", "balanced_accuracy", "macro_f1", "kappa"]].agg(["mean", "std"])
        summary.to_csv(args.output_dir / "subject_level_summary.csv")
        metadata.update({"status": "complete", "end_utc": utcnow(), "elapsed_seconds": time.perf_counter() - t0,
                         "E_labels_loaded": True, "label_use": "only after global prediction lock; layout checks and scoring"})
        save_json(args.output_dir / "run_metadata.json", metadata)
        print(summary.to_string(), flush=True)
        print(f"Completed in {time.perf_counter() - t0:.1f}s", flush=True)


if __name__ == "__main__":
    main()
