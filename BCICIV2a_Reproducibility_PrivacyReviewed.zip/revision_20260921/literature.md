# Primary-source verification for the September revision

Verified 2026-09-22. These are contextual literature results, not extra experiments in this study. None establishes a head-to-head ranking against our implementation. No numerical EEGNet result was guessed from an unlabelled plot.

## Ang et al.: the relevant official evaluation result

K. K. Ang, Z. Y. Chin, C. Wang, C. Guan, and H. Zhang, “Filter Bank Common Spatial Pattern Algorithm on BCI Competition IV Datasets 2a and 2b,” *Frontiers in Neuroscience*, vol. 6, Art. no. 39, 2012, doi: [10.3389/fnins.2012.00039](https://doi.org/10.3389/fnins.2012.00039).

Evidence: [author-hosted full paper](https://personal.ntu.edu.sg/ctguan/Publications/2012_KaiKeng_Frontiers_in_Neuroscience.pdf), Table 2 (PDF p. 7), Sections 2.1, 2.4 and 3.1.1.

- Official unseen session evaluation: mean kappa **0.569 for OVR**, **0.572 for pairwise**, 0.520 for divide-and-conquer. Do not confuse OVR training cross-validation kappa 0.663 with held-out evaluation.
- Training used cue +0.5–2.5 s; the evaluation emitted causal two-second sliding-window predictions. Competition scoring used maximum kappa across the time course, unlike our fixed-window offline score.
- Nine causal Chebyshev-II bands covered 4–40 Hz; the classifier was naive Bayesian Parzen window. Our eight-band 4–36 Hz Butterworth/SVM implementation is not an exact replication.
- Consequently, the original local FBCSP kappa 0.453 is lower numerically, but a causal explanation requires controlled ablations. **The two-second training window is shared**, not a valid stand-alone explanation for this difference.

Tangermann et al., “Review of the BCI Competition IV,” *Frontiers in Neuroscience*, vol. 6, Art. no. 55, 2012, [doi:10.3389/fnins.2012.00055](https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2012.00055/full), Section 5.5 and Table 3 independently record the winning mean kappa as 0.57. T-to-E is the established dataset protocol, not a new contribution of this manuscript.

## Lawhern et al.: why an invented T-to-E accuracy is inappropriate

V. J. Lawhern, A. J. Solon, N. R. Waytowich, S. M. Gordon, C. P. Hung, and B. J. Lance, “EEGNet: a compact convolutional neural network for EEG-based brain–computer interfaces,” *Journal of Neural Engineering*, vol. 15, no. 5, Art. no. 056013, 2018, doi: [10.1088/1741-2552/aace8c](https://doi.org/10.1088/1741-2552/aace8c).

Evidence: [author manuscript v4](https://arxiv.org/pdf/1611.08024), Sections 2.1.4, 2.2.1, 2.3; Tables 1–2; Figures 3 and 5.

- SMR is BCICIV2a; preprocessing uses 128 Hz, 4–40 Hz and cue +0.5–2.5 s.
- Within-subject evaluation is four-fold blockwise training/validation/test partitioning of 50%/25%/25%; Figure 3 is not a nine-subject official T-to-E mean with an exact tabulated accuracy.
- Cross-subject SMR training uses five other subjects, validation three others, and testing the held-out participant’s official E set, repeated ten times. This is not same-participant T-to-E.
- Original architecture flattens the post-pooling time dimension into the softmax classifier and constrains weights; our global temporal pooling and optimization differ. Call ours **EEGNet-style**, not an exact EEGNet reproduction.
- Figure 3 supports similar EEGNet-8,2 and FBCSP performance, not an exact numerical T-to-E claim. No number is supplied here.

## Additional contextual references

### Euclidean alignment

H. He and D. Wu, “Transfer Learning for Brain–Computer Interfaces: A Euclidean Space Data Alignment Approach,” *IEEE Transactions on Biomedical Engineering*, vol. 67, no. 2, pp. 399–410, **2020**, doi: [10.1109/TBME.2019.2913914](https://doi.org/10.1109/TBME.2019.2913914).

The DOI contains 2019 (online publication); the paginated journal issue is 2020. [Author manuscript](https://arxiv.org/pdf/1808.05464), Section III.A, equations (10)–(12): align trials using the inverse square root of their arithmetic mean covariance; the aligned mean is identity. No target labels are required. Our per-session extension uses all unlabeled E signals and is therefore transductive, not source-only or real-time causal. Bibliographic details are also listed in [the authors’ IEEE Brain article](https://brain.ieee.org/newsletter/2020-issue-1/transfer-learning-for-brain-computer-interfaces-euclidean-alignment-and-label-alignment/).

### MOABB

V. Jayaram and A. Barachant, “MOABB: trustworthy algorithm benchmarking for BCIs,” *Journal of Neural Engineering*, vol. 15, no. 6, Art. no. 066011, 2018, doi: [10.1088/1741-2552/aadea0](https://doi.org/10.1088/1741-2552/aadea0).

Verified in [official MOABB documentation](https://moabb.neurotechx.com/) and [author manuscript](https://arxiv.org/abs/1805.06427). Cite as motivation for standardized reproducible, multi-dataset comparison. Our pipeline is custom; do not say experiments were run through MOABB.

### Shallow ConvNet / Braindecode

R. T. Schirrmeister, J. T. Springenberg, L. D. J. Fiederer, M. Glasstetter, K. Eggensperger, M. Tangermann, F. Hutter, W. Burgard, and T. Ball, “Deep learning with convolutional neural networks for EEG decoding and visualization,” *Human Brain Mapping*, vol. 38, no. 11, pp. 5391–5420, 2017, doi: [10.1002/hbm.23730](https://onlinelibrary.wiley.com/doi/10.1002/hbm.23730).

The publisher’s full text, “Validation of FBCSP Baseline,” reports 67.6% for a 0.5–2.5 s window and 67.8% for 0.5–4 s. Table 2 lists FBCSP 67.8% on BCICIV2a at 4–38 Hz, with shallow ConvNet +4.1 percentage points (thus **71.9%**, arithmetic derived from the table). Neural comparisons used cropped training. These contextual values are not a matched implementation comparison with our trial-wise EEGNet-style network. Shallow ConvNet explicitly learns temporal/spatial filters then uses square, mean-pool and log operations to model band power. It is relevant related work, **not an experimentally evaluated baseline in our paper**.

### FBCNet

R. Mane, E. Chew, K. Chua, K. K. Ang, N. Robinson, A. P. Vinod, S.-W. Lee, and C. Guan, “FBCNet: A Multi-view Convolutional Neural Network for Brain-Computer Interface,” **arXiv preprint arXiv:2104.01233**, 2021, doi: [10.48550/arXiv.2104.01233](https://arxiv.org/abs/2104.01233).

The authors describe filter-bank views, spatial filtering, and a variance layer. Cite as a relevant spectral neural design omitted from our empirical scope. This verified item is a preprint; do not invent conference/journal pages or call the 2021 preprint peer-reviewed. The abstract’s 76.20% must not be inserted into a matched T-to-E table without checking its exact evaluation details; we do not need that numerical claim here.

## Interpretation guardrails for the revised manuscript

- Metric choice cannot explain a low **accuracy or kappa** when comparing those same metrics. Macro-F1 addresses different aspects of errors; it does not turn inferior accuracy into an apparent artifact.
- No trial rejection, global-pooling simplification, filter and classifier differences are possible implementation explanations, not experimentally established causes. Cite verified preprocessing differences; do not claim another work removed trials without direct evidence.
- Standard T-to-E evaluation and EA are established methods. Our contribution should be framed as a transparent controlled audit (seed/ensemble, source-only tuning, and target-signal access), with scope and negative results visible.
- Neither a reference nor a GitHub URL for another author makes our own code publicly accessible. Public release remains outstanding until the author actually publishes the prepared package.
