# Local publication preparation and redaction record

This directory is a local publication candidate prepared on 2026-10-02. Its
creation does not mean it has been uploaded or made public. No public URL or DOI
is assigned here, and no software license has been added or selected.

## Scope

The input was `BCICIV2a_Revision_Reproducibility.zip`. This copy contains the same
experiment code, configurations, derived results, and reproduction documentation.
It does not include the manuscript, teacher comments, raw EEG recordings, raw
evaluation-label archives, or third-party software binaries. Saved EA matrices
are derived covariance references and whitening matrices, not raw EEG trials.

## Privacy-only transformations

Exactly three existing files have changed:

- `reproducibility/results_final_ensemble/run_metadata.json`: the original
  machine's data and output directory strings were replaced with
  `<LOCAL_DATA_DIR>` and `<LOCAL_ORIGINAL_RESULTS_DIR>`.
- `reproducibility/results_final_ensemble/run_stdout.log`: the final output
  directory string was replaced with `<LOCAL_ORIGINAL_RESULTS_DIR>`.
- `revision_20260921/experiments/results/run_metadata.json`: the machine-specific
  data directory in the recorded command was replaced with `<LOCAL_DATA_DIR>`.

These placeholders are explanatory, not runnable path arguments. Supply your own
data and output directories when rerunning the experiments. Timing, configuration,
software-version fields, predictions, metrics, and embedded experiment-script
hashes were not changed. Every original file other than the three listed above
is byte-identical to its source archive member. The original archive and local
experiment records were preserved without modification.

`REDACTION_RECORD.json` records the source archive checksum and both original and
publication checksums for these three files. `SHA256SUMS.json` was regenerated for
every file in this copy other than the checksum manifest itself. It replaces the
archive's old manifest because the privacy redactions and this note change the
publication package bytes.

## Pending before public release

Confirm code ownership/provenance, software-license choice, and applicable data
use and submission-anonymity conditions. Review the final file list, then publish
only this scoped release copy if authorized. Update README availability wording
and the paper only after a real repository URL or DOI is verified. A text-pattern
scan found no remaining Windows absolute paths, home-directory paths, or common
credential patterns; this is a bounded check, not a universal security guarantee.

The archived benchmark's opening docstring is older than the final protocol:
the authoritative protocol/metadata describe six-run leave-one-run-out source
validation and the custom EEGNet-style probability ensemble. The revision README
also distinguishes source-only pipelines from batch-transductive EA. Frozen
experiment scripts were not edited to change historical wording.
